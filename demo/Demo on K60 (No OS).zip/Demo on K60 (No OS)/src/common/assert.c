/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		assert.c
** Descriptions:	procedure for assert condition failed. Provide macro for software assertions.
** Notes:           ASSERT macro defined in assert.h calls assert_failed()
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#include "system.h"


/*************************extern variable declaration**************************/


/*************************extern function declaration**************************/


/****************************variable declaration******************************/
const char ASSERT_FAILED_STR[] = "Assertion failed in %s at line %d. Please check the reason for the error!\n";


/****************************function declaration******************************/


/*******************************************************************************
Procedure     :	assert_failed
Arguments     : Null
Return	      : Null
Description   : Failure of assertion lead to enter a error state and print out
                error information.  
*******************************************************************************/
void assert_failed(char *file, int line)
{
    while (1)
    {
    #ifdef DEBUG_PRINT
        printf(ASSERT_FAILED_STR, file, line);  //print error information
    #endif
    }
}
