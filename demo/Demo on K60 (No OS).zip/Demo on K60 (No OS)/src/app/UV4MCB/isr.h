/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		isr.h
** Descriptions:	interruption service routine defines
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef _ISR_H_
#define _ISR_H_


#ifdef __cplusplus
extern "C" 	{
#endif


extern  void 	UART1_IRQHandler(void);

#undef  VECTOR_063
#define VECTOR_063  UART1_IRQHandler


#ifdef __cplusplus 
} 
#endif 

#endif /* _ISR_H_ */
