/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		include.h
** Descriptions:	total header including file
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef __INCLUDE_H__
#define __INCLUDE_H__


#include "system.h"

#include "gpio.h"      //IO operation
#include "uart.h"      //UART operation
#include "mbs.h"
#include "mbs1.h"

#endif  //__INCLUDE_H__
