/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		main.c
** Descriptions:	Definition of main function
** Comment:         Built with IAR Embedded Workbench for ARM 6.50  
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#include <stdio.h> 
#include "include.h"


/*************************extern variable declaration**************************/


/*************************extern function declaration**************************/


/****************************variable declaration******************************/


/****************************function declaration******************************/


/*******************************************************************************
Procedure     :	main
Arguments 	  : Null 
Return        : int
Description	  : main entrance of this project
Comment   	  : 
*******************************************************************************/
void main(void)
{  
    /* initialize global timer */
    GtimeInit(); //
    
    /* Initialization of Modbus instance 1 */
	Mbs1Init(DFT_MB1_BAUD, DFT_MB1_PARITY, DFT_MB1_ID);
		
    /* Main Loop */
    while(1)
    {			
        /* polling Modbus */
		Mbs1Srv();						
     }
}

