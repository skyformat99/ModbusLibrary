/*************************************************************************
**Copyright (c) 2013 Trojan Technologies Inc. 
**All rights reserved.
**
** File name:		mbs1.h
** Descriptions:	modbus module 1 service
**------------------------------------------------------------------------
** Version:			1.0
** Created by:		Hengguang 
** Created date:	2013-10-12
** Descriptions:	The original version
**------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
**************************************************************************/
#ifndef __MBS1_H__
#define __MBS1_H__


#include "mbs.h"

#ifdef __cplusplus
extern "C" 	{
#endif



/******************************macro definition********************************/
#define	DFT_MB1_ID		4 		//default modbus device address
#define	DFT_MB1_BAUD	115200 	//default baud rate
#define	DFT_MB1_PARITY	'N' 	//default parity 

//defines of modbus register areas 
#define MB1_REG_SIZE			40
#define MB1_REG_STADDR			0
#define MB1_RW_REG_STADDR		30
#define MB1_RW_REG_SIZE			10


/*******************************data definition********************************/


/****************************variable declaration******************************/
extern	MB_RTU_SLV		mbs1; //modbus object


/*******************************macro operation********************************/


/****************************function declaration******************************/
extern uint8 	Mbs1Init(uint32 baud, uint8 parity, uint8 devAddr);
extern void 	Mbs1Srv(void);


#ifdef __cplusplus 
} 
#endif 

#endif



