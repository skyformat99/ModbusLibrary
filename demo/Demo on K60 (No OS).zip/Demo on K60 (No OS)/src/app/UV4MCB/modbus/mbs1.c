/*************************************************************************
**Copyright (c) 2013 Trojan Technologies Inc. 
**All rights reserved.
**
** File name:		mbs1.c
** Descriptions:	modbus module 1 service
**------------------------------------------------------------------------
** Version:			1.0
** Created by:		Hengguang 
** Created date:	2013-10-12
** Descriptions:	The original version
**------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
**************************************************************************/
#include "include.h"
#include "mbs.h"
#include "mbs1.h"


//define of size of send buffer 
#define SND_BUF_SIZE		255 //16~255


/********************extern variable declaration**************************/


/********************extern function declaration**************************/


/*********************variable declaration********************************/
MB_RTU_SLV		mbs1;

static	uint8		sndBuf[SND_BUF_SIZE] = {0};
static	uint16		mbReg[MB1_REG_SIZE] = {0};


/********************function declaration*********************************/
static	BOOL8	MbsPortInit(uint32 baud, uint8 parity, uint16 frmSpace);
static	uint16 	MbsGetRcvCnt(void);
static	uint32 	MbsGetLastRcvTime(void);
static	uint16 	MbsRcvFrm(uint8 *pDes);
static	BOOL8	MbsIsSndIdle(void);
static	BOOL8  	MbsSndFrm(uint8 *pFrm, uint16 size);


/*************************************************************************
Function Name :	Mbs1Init
Arguments 	  : [in]baud: baud rate(2400-115200 bps)
				[in]parity: parity setting, ('N' 'E' or 'O')
				[in]devAddr: address of slave device, (1-247) 
Return		  : TRUE-success
				FALSE-failed (invalid arguments)
Description	  : Modbus-RTU slave initialization.
**************************************************************************/
uint8 Mbs1Init(uint32 baud, uint8 parity, uint8 devAddr)
{
	return MbsInit(&mbs1, baud, parity, devAddr, mbReg, MB1_REG_SIZE, 
					MB1_REG_STADDR, MB1_RW_REG_STADDR, MB1_RW_REG_SIZE, 
					sndBuf, SND_BUF_SIZE, 
					MbsPortInit, MbsGetRcvCnt, MbsGetLastRcvTime,
					MbsRcvFrm, MbsIsSndIdle, MbsSndFrm);
}

/*************************************************************************
Function Name :	MbsPortInit
Arguments 	  : [in]baud: baud rate(2400-115200 bps)
				[in]parity: parity setting, ('N' 'E' or 'O')
				[in]frmSpace: setting of min space time between frame (unit: ms)
Return		  : TRUE-success
				FALSE-failed (invalid arguments)
Description	  : Port initialization for modbus.
**************************************************************************/
BOOL8 MbsPortInit(uint32 baud, uint8 parity, uint16 frmSpace)
{
	return UartInit(UART1, baud, parity, frmSpace);
}

/*************************************************************************
Function Name :	MbsGetRcvCnt
Arguments 	  : Null
Return		  : count of received data 
Description	  : Get count of received data for modbus.
**************************************************************************/
uint16 MbsGetRcvCnt()
{
	return UartGetRxCnt(UART1);
}

/*************************************************************************
Function Name :	MbsGetLastRcvTime
Arguments 	  : Null
Return		  : time of last data received (ms)
Description	  : Get time of last data received of modbus.
**************************************************************************/
uint32 MbsGetLastRcvTime()
{
	return UartGetLastRxTime(UART1);
}

/*************************************************************************
Function Name :	MbsRcvFrm
Arguments 	  : [out]pDes: destination to save received frame
Return		  : length of received frame
Description	  : Get received modbus frame out from port.
**************************************************************************/
uint16 MbsRcvFrm(uint8 *pDes)
{
	return UartGetRxData(UART1, pDes, 0);
}

/*************************************************************************
Function Name :	Mbs1sSndIdle
Arguments 	  : Null
Return		  : TRUE- port is idle for sending 
				FALSE- port is busy for sending 
Description	  : Check whether port is idle for sending of modbus.
**************************************************************************/
BOOL8 MbsIsSndIdle()
{
	/*	Note: for half-duplex mode, sending is always idle while received 
	 *	a frame, so can ignore check and always return TRUE here 
	 */
	return UartIsTxIdle(UART1);
}

/*************************************************************************
Function Name :	MbsSndFrm
Arguments 	  : [in]pFrm: pointer to the frame to be send out
				[in]size: length of frame
Return		  : TRUE-sending successful, 
				FALSE-sending failed, buffer is full
Description	  : Send modbus frame out.
**************************************************************************/
BOOL8 MbsSndFrm(uint8 *pFrm, uint16 size)
{
	if (!UartPutTxData(UART1, pFrm, size))
		return FALSE;
	
	UartTxStart(UART1);
	return TRUE;
}


/*************************************************************************
Function Name :	Mbs1Srv
Arguments 	  : Null
Return		  : Null
Description	  : Main entrence of modbus-RTU slave service of module 1.
**************************************************************************/
void Mbs1Srv()
{
	MbsSrv(&mbs1);
}



