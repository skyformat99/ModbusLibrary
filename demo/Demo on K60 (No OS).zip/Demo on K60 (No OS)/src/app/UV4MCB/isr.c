/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		isr.c
** Descriptions:	interruption service routine
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#include "include.h"
//#include "isr.h"


/*************************extern variable declaration**************************/


/*************************extern function declaration**************************/


/****************************variable declaration******************************/


/****************************function declaration******************************/



/*******************************************************************************
Procedure     :	HardFault_Handler
Arguments 	  : Null
Return		  : Null
Description	  : Hardware  fault interruption service routine.
*******************************************************************************/
void HardFault_Handler(void)
{
    while (1)
    {
        printf("\n****hardware fault*****\r\n\n");
    }
}


