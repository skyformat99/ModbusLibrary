/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		system.h
** Descriptions:	system related definitions
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-12
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef SYSTEM_H
#define SYSTEM_H

//#include "MK60DZ10.h"
#include <freescale/MK60DZ10.h>//MK60N512VMD100.h
#include <intrinsics.h>
#include <stdio.h>
#include "common.h"
#include "arm_cm4.h"
#include "vectors.h"

#include "assert.h"
#include "startup.h"
#include "sysinit.h"       //system config initialization
#include "mcg.h"
#include "gpio_cfg.h"

#include "pit.h"


#undef  DEBUG_PRINT
#ifdef DEBUG
    #define DEBUG_PRINT
#endif

//should disable printf and PLL in simulator mode
//#define   Simulator
#ifdef    Simulator
  #define NO_PLL_INIT   //disable PLL
  #define NPRINTF       //disable printf
  #undef  DEBUG_PRINT
#endif


#define MCG_CLK_MHZ     PLL100
#define CRYSTAL_OPT     EXTAL50

#define PRINT_PORT  UART3
#define PRINT_BAUD  115200


#endif



