/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		arm_cm4.h
** Descriptions:	common core functions for ARM Cotex-M4 
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		ARM (CMSIS lib) 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef _CPU_ARM_CM4_H
#define _CPU_ARM_CM4_H


#ifdef __cplusplus
extern "C" 	{
#endif

  
/*ARM Cortex M4 implementation for interrupt priority shift*/
#define ARM_INTERRUPT_LEVEL_BITS        4

/*!< Macro to enable all interrupts. */
#define EnableInterrupts    asm(" CPSIE i");

/*!< Macro to disable all interrupts. */
#define DisableInterrupts   asm(" CPSID i");
  
  
/***********************************************************************/
/*
 * Misc. Defines
 */

/***********************************************************************/
/*
 * The basic data types
 */
  
  
// function prototypes for arm_cm4.c
void stop (void);
void wait (void);
void write_vtor (int);
void enable_irq (int);
void disable_irq (int);
void set_irq_priority (int, int);

// function prototype for main function
void main(void);


#ifdef __cplusplus 
} 
#endif 

#endif	/* _CPU_ARM_CM4_H */

