/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		startup.h
** Descriptions:	CPU startup related functions
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef _STARTUP_H_
#define _STARTUP_H_


#ifdef __cplusplus
extern "C" 	{
#endif

  
extern  void    cpu_identify(void);
extern  void    flash_identify(void);
extern  void    common_startup(void);


#ifdef __cplusplus 
} 
#endif 

#endif /* _STARTUP_H_ */
