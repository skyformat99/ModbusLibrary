/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		sysinit.h
** Descriptions:	functions for system related initialization
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef    _SYSINIT_H_
#define    _SYSINIT_H_


#ifdef __cplusplus
extern "C" 	{
#endif


extern  uint32  core_clk_khz;
extern  uint32  core_clk_mhz;
extern  uint32  bus_clk_khz;


//function prototypes
extern  void    sysinit (void);
extern  void    trace_clk_init(void);
extern  void    fb_clk_init(void);
extern  void    enable_abort_button(void);


#ifdef __cplusplus 
} 
#endif 

#endif  //_SYSINIT_H_