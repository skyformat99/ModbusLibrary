/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		sysinit.c
** Descriptions:	system related initial functions, like colck, printf...
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#include "system.h"
#include "sysinit.h"
#include "uart.h"


/*************************extern variable declaration**************************/


/*************************extern function declaration**************************/


/****************************variable declaration******************************/


/****************************function declaration******************************/



/*******************************************************************************
Procedure     :	sysinit
Arguments     : Null
Return	      : Null
Description   : system related initialization
*******************************************************************************/
void sysinit (void)
{
    /* enable all PORT timers */
    SIM_SCGC5 |= (SIM_SCGC5_PORTA_MASK
                  | SIM_SCGC5_PORTB_MASK
                  | SIM_SCGC5_PORTC_MASK
                  | SIM_SCGC5_PORTD_MASK
                  | SIM_SCGC5_PORTE_MASK );

#if defined(NO_PLL_INIT)
    core_clk_mhz = 20;  //enter FEI mode if NO_PLL_INIT defined
#else
    /* PLL clock mode  */
    core_clk_mhz = SystemClockInit(MCG_CLK_MHZ, CRYSTAL_OPT);
#endif

    core_clk_khz = core_clk_mhz * 1000;
    bus_clk_khz = core_clk_khz / (((SIM_CLKDIV1 & SIM_CLKDIV1_OUTDIV2_MASK) >> 24)+ 1);

    trace_clk_init();   //enable trace clock, used for debug
    fb_clk_init();      //initialize FlexBus clodk
}

/*******************************************************************************
Procedure     :	trace_clk_init
Arguments     : Null
Return	      : Null
Description   : enable trace clock, used for debug
*******************************************************************************/
void trace_clk_init(void)
{
    /* Set the trace clock to the core clock frequency */
    SIM_SOPT2 |= SIM_SOPT2_TRACECLKSEL_MASK;

    /* Enable the TRACE_CLKOUT pin function on PTA6 (alt7 function) */
    PORTA_PCR6 = ( PORT_PCR_MUX(0x7));
}

/*******************************************************************************
Procedure     :	fb_clk_init
Arguments     : Null
Return	      : Null
Description   : initialize FlexBus clodk
*******************************************************************************/
void fb_clk_init(void)
{
    /* Enable the clock to the FlexBus module */
    SIM_SCGC7 |= SIM_SCGC7_FLEXBUS_MASK;

    /* Enable the FB_CLKOUT function on PTC3 (alt5 function) */
    PORTC_PCR3 = ( PORT_PCR_MUX(0x5));
}
