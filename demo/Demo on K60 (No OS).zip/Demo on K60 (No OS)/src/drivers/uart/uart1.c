/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		uart1.c
** Descriptions:	UART1 specific driver
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-09-27
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#include "system.h"
#include "uart.h"
#include "uart1.h"


#define	BUF_SIZE1		256
#define	BUF_SIZE2		256

#define RS485_RT_PIN() 	PORTC_PCR2 = PORT_PCR_MUX(1); GPIOC_PDDR = (1UL << 2) //set PTC2 as output pin, used for RT select.
#define RS485_SEL_RX() 	GPIOC_PCOR = (1UL << 2);
#define RS485_SEL_TX() 	GPIOC_PSOR = (1UL << 2);


/*************************extern variable declaration**************************/


/*************************extern function declaration**************************/


/****************************variable declaration******************************/
static	uint8	 buf1[BUF_SIZE1]; //for Rx
static	uint8	 buf2[BUF_SIZE2]; //for Tx
static	volatile CIRCLEBUF  rxBuf, txBuf;
static	volatile RTX_CTRL   rtxCtrl; 


/****************************function declaration******************************/
static	void 	Uart1SwitchToTx(void);
static	void 	Uart1SwitchToRx(void);


/*******************************************************************************
Procedure     :	Uart1Init
Arguments     : [in]baud: wanted baud rate
				[in]parity: parity setting, ('N' 'E' or 'O')
				[in]txSpace: setting of min space time between frame (unit: ms)
Return	      : TRUE-Initialization success
				FALSE-Initialization failed (invalid input)
Description   : Initialize UART1, set baudrate and parity.
*******************************************************************************/
uint8 Uart1Init(uint32 baud, uint8 parity, uint16 txSpace)
{
    uart_init(UART1, baud, parity);
    
    Uart0IOSet();
    
	if (Uart0RxBufSet() == FALSE)
		return FALSE;
	
	if (Uart0TxBufSet() == FALSE)
		return FALSE;
    
    Uart0RTxCtrlInit(txSpace);
    
    uart_irq_EN(UART1);

	return TRUE;
}

/*******************************************************************************
Procedure     :	Uart1IOSet
Arguments 	  : Null
Return		  : Null
Description	  : Set IOs for the UART1
*******************************************************************************/
inline void Uart1IOSet(void)
{
#ifdef UART1_USE_RT_SWITCH
  	RS485_RT_PIN(); //RT pin initial 
  	Uart1SwitchToRx(); //set RS485 to RX mode at initial
#endif
}


/*******************************************************************************
Procedure     :	Uart1SwitchToTx
Arguments 	  : Null
Return		  : Null
Description	  : switch UART1 to TX mode
*******************************************************************************/
inline	void Uart1SwitchToTx(void)
{
#ifdef UART1_USE_RT_SWITCH
	RS485_SEL_TX();
#endif
}

/*******************************************************************************
Procedure     :	Uart1SwitchToRx
Arguments 	  : Null
Return		  : Null
Description	  : switch UART0 to RX mode
*******************************************************************************/
inline	void Uart1SwitchToRx(void)
{
#ifdef UART1_USE_RT_SWITCH
	RS485_SEL_RX();
#endif
}

/*******************************************************************************
Procedure     :	Uart1PollOnTxc //Uart0SwitchToRxAfterTxc
Arguments 	  : Null
Return		  : Null
Description	  : Controls after TX completion on polling mode.
*******************************************************************************/
void Uart1PollOnTxc(void)
{
#ifdef UART1_USE_RT_SWITCH
	while (!(UART1_S1 & UART_S1_TC_MASK));
	Uart1SwitchToRx();
#endif
}

/*******************************************************************************
Procedure     :	Uart1RxBufSet
Arguments 	  : Null 
Return		  : pointer to the RX buffer if successful,
				or return FALSE if failed
Description	  : Set circle RX buffer for UART1
*******************************************************************************/
void* Uart1RxBufSet()
{
	if (CBufInit((CIRCLEBUF*)&rxBuf, buf1, BUF_SIZE1))
		return ((CIRCLEBUF*)&rxBuf);
	
	return FALSE;
}

/*******************************************************************************
Procedure     :	Uart1TxBufSet
Arguments 	  : Null
Return		  : pointer to the TX buffer if successful,
				or return FALSE if failed
Description	  : Set circle TX buffer for UART1
*******************************************************************************/
CIRCLEBUF* Uart1TxBufSet()
{
	if (CBufInit((CIRCLEBUF*)&txBuf, buf2, BUF_SIZE2))
		return ((CIRCLEBUF*)&txBuf);

	return FALSE;
}

/*******************************************************************************
Procedure     :	Uart1RTxCtrlInit
Arguments     : None
Return	      : pointer to the Rx&Tx control structure 
Description   : Initialize RX and TX control strcture for UART1.
*******************************************************************************/
RTX_CTRL* Uart1RTxCtrlInit()
{
	rtxCtrl.pfPreTx = Uart1SwitchToTx;
	rtxCtrl.pfPostTx = Uart1SwitchToRx;
	return ((RTX_CTRL*)&rtxCtrl);
}


/*******************************************************************************
Procedure     :	UART1_IRQHandler
Arguments 	  : Null
Return		  : Null
Description	  : Interrupt service routine for UART1 status sources.
*******************************************************************************/
void UART1_IRQHandler(void)
{ 
   UartIsr(UART1);
}
