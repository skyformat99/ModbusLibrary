/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		uart.h
** Descriptions:	UART related operations
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef __UART_H__
#define __UART_H__

#ifdef __cplusplus
extern "C" 	{
#endif

  
/******************************macro definition********************************/
//module channel    port    optional  ports             suggestion
#define UART0_RX    PTD6    //PTA1, PTA15, PTB16, PTD6  deprecated PTA1(conflict with JTAG)
#define UART0_TX    PTD7    //PTA2, PTA14, PTB17, PTD7  deprecated PTA2(conflict with JTAG)

#define UART1_RX    PTC3    //PTC3, PTE1
#define UART1_TX    PTC4    //PTC4, PTE0

#define UART2_RX    PTD2    //PTD2
#define UART2_TX    PTD3    //PTD3

#define UART3_RX    PTB10   //PTB10, PTC16, PTE5
#define UART3_TX    PTB11   //PTB11, PTC17, PTE4

#define UART4_RX    PTC14   //PTC14, PTE25
#define UART4_TX    PTC15   //PTC15, PTE24

#define UART5_RX    PTE9    //PTD8, PTE9
#define UART5_TX    PTE8    //PTD9, PTE8

  
//bound of baud rate, be related with Fosc
#define	BAUD_MIN			2400
#define	BAUD_MAX			115200

  
/*******************************data definition********************************/
typedef enum  UARTn
{   //default cfg   --TXD--      --RXD--     can use other channel, but please modify uart_init by yourself 
    UART0,          //PTD6         PTD7
    UART1,          //PTC4         PTC3
    UART2,          //PTD3         PTD2
    UART3,          //PTC17        PTC16
    UART4,          //PTE24        PTE25
    UART5           //PTE8         PTE9
}UARTn;


//type define of UART Rx and Tx control information 
typedef struct 
{
	uint32	lastRxTime;//get from system tick, unit: ms
	uint32	lastTxTime;//get from system tick, unit: ms
	uint16	txSpaceSet;//min tx space time between frame, unit: ms
	uint8	txing; //being TX flag
    pfvoid  pfPreTx; //action before Tx
    pfvoid  pfPostTx; //action after Tx
}RTX_CTRL;

/****************************variable declaration******************************/
//extern volatile struct UART_MemMap *UARTx[6];


/*******************************macro operation********************************/
#define UART_IRQ_EN(UARTn)   	UART_C2_REG(UARTx[UARTn]) |= UART_C2_RIE_MASK; enable_irq((UARTn<<1)+45)    
#define UART_IRQ_DIS(UARTn)  	UART_C2_REG(UARTx[UARTn]) &= ~(UART_C2_RIE_MASK | UART_C2_TIE_MASK | UART_C2_TCIE_MASK); disable_irq((UARTn<<1)+45)  

#define UART_RI_EN(UARTn)  		UART_C2_REG(UARTx[UARTn]) |= UART_C2_RIE_MASK //Enable Receiver interruption   
#define UART_RI_DIS(UARTn)   	UART_C2_REG(UARTx[UARTn]) &= ~UART_C2_RIE_MASK //Disable Receiver interruption     

#define UART_TI_EN(UARTn)   	UART_C2_REG(UARTx[UARTn]) |= UART_C2_TIE_MASK //Enable Transmitter interruption    
#define UART_TI_DIS(UARTn)   	UART_C2_REG(UARTx[UARTn]) &= ~UART_C2_TIE_MASK //Disable Transmitter interruption    
#define UART_TCI_EN(UARTn)   	UART_C2_REG(UARTx[UARTn]) |= UART_C2_TCIE_MASK //Enable Transmitter Complete interruption  
#define UART_TCI_DIS(UARTn)   	UART_C2_REG(UARTx[UARTn]) &= ~UART_C2_TCIE_MASK //Disable Transmitter Complete interruption  
#define UART_TI_TCI_EN(UARTn)   UART_C2_REG(UARTx[UARTn]) |= (UART_C2_TIE_MASK | UART_C2_TCIE_MASK) //Enable all transmitter interruption    
#define UART_TI_TCI_DIS(UARTn)	UART_C2_REG(UARTx[UARTn]) &= ~(UART_C2_TIE_MASK | UART_C2_TCIE_MASK) //Disable all transmitter interruption    

//#define UART_ON_PRE_TX(UARTn)	pRTxCtrl[UARTn]->pfPreTx()
//#define UART_ON_POST_TX(UARTn)	pRTxCtrl[UARTn]->pfPostTx()


/****************************function declaration******************************/
//base UART driver
extern  void    uart_init(UARTn, uint32 baud, uint8 parity);                     
extern  void 	uart_parity(UARTn uartn, uint8 parity);

extern  char    uart_getchar(UARTn);                    
extern  char    uart_pendchar(UARTn, char *ch);             
extern  char    uart_pendstr(UARTn, char *str);              

extern  int     uart_query(UARTn);                      

extern  void    uart_putchar(UARTn, char ch);                  
extern  void    uart_sendN(UARTn, uint8 *buff, uint16 len);  
extern  void    uart_sendStr(UARTn, const uint8 *str);         

extern  void    uart_irq_EN(UARTn);                    
extern  void    uart_irq_DIS(UARTn);                    


//UART driver with circle buffer
extern  uint8 	UartInit(UARTn uartn, uint32 baud, uint8 parity, uint16 txSpace);

extern  void 	UartOnPreTx(UARTn uartn);
extern  void 	UartOnPostTx(UARTn uartn);
extern  uint32 	UartGetLastRxTime(UARTn uartn);
extern  uint32 	UartGetLastTxTime(UARTn uartn);
extern  uint16 	UartGetRxCnt(UARTn uartn);
extern  uint16 	UartGetTxSpareSize(UARTn uartn);

extern  BOOL8 	UartIsTxIdle(UARTn uartn);
extern  void 	UartLoopUntilTxIdle(UARTn uartn);
extern  uint16 	UartPutTxData(UARTn uartn, uint8* pData, uint16 len);
extern  uint16 	UartGetRxData(UARTn uartn, uint8* pDes, uint16 len);

extern  uint8 	UartTxStart(UARTn uartn);
extern  uint8 	UartTxBlock(UARTn uartn);
extern  void 	UartTxPolling(UARTn uartn, uint8* pData, uint16 len);
extern  int 	UartPutchar(UARTn uartn, char ch);

extern  void 	UartIsr(UARTn uartn);

extern  void 	UartSrv(UARTn uartn);



#ifdef __cplusplus 
} 
#endif 

#endif /* __UART_H__ */
