/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		uart.c
** Descriptions:	procedure of UART operation
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#include "system.h"
#include "uart.h"
#include "uart1.h"



/*************************extern variable declaration**************************/


/*************************extern function declaration**************************/


/****************************variable declaration******************************/
//define 5 pointer array to save address of UARTx
static volatile struct UART_MemMap *UARTx[6] = {UART0_BASE_PTR,UART1_BASE_PTR,UART2_BASE_PTR,UART3_BASE_PTR,UART4_BASE_PTR,UART5_BASE_PTR}; 
static volatile CIRCLEBUF   *pRxBuf[6] = {0}; 
static volatile CIRCLEBUF   *pTxBuf[6] = {0}; 
static volatile RTX_CTRL    *pRTxCtrl[6] = {0}; 
//static /*volatile*/ CIRCLEBUF   *pRxBuf[6] = {0}; 
//static /*volatile*/ CIRCLEBUF   *pTxBuf[6] = {0}; 
//static /*volatile*/ RTX_CTRL    *pRTxCtrl[6] = {0}; 


/****************************function declaration******************************/
static 	void 	uart_parity(UARTn uartn, uint8 parity);
static 	void 	UartIOSet(UARTn uartn);
static 	void* 	UartRxBufSet(UARTn uartn);
static 	void* 	UartTxBufSet(UARTn uartn);
static 	void 	RTxCtrlInit(UARTn uartn, uint16 txSpace);
static 	void 	UartPollOnTxc(UARTn uartn);
static 	BOOL8 	UartIsTxLineIdle(UARTn uartn);
static 	void 	UartLoopUntilTxLineIdle(UARTn uartn);
static 	void 	UartIsrOnRDRF(UARTn uartn);
static 	void 	UartIsrOnTDRE(UARTn uartn);
static 	void 	UartIsrOnTC(UARTn uartn);
static 	void 	UartRxSrv(UARTn uartn);
static 	void 	UartTxSrv(UARTn uartn);


/*******************************************************************************
Procedure     :	uart_init
Arguments     : [in]uartn: UART number (UART0~UART5)
                [in]baud: wanted baud rate
                [in]parity: parity setting, ('N' 'E' or 'O')
Return	      : Null
Description   : Initialize UART, set baudrate and parity.
*******************************************************************************/
void uart_init (UARTn uartn, uint32 baud, uint8 parity)
{
    register uint16 sbr, brfa;
    uint8 temp;
    uint32 sysclk;     

    switch(uartn)
    {
    case UART0:
        if(UART0_RX==PTA1)
            PORTA_PCR1 = PORT_PCR_MUX(0x2);      //enable UART0_RXD on PTA1
        else if(UART0_RX==PTA15)
            PORTA_PCR15 = PORT_PCR_MUX(0x3);     //enable UART0_RXD on PTA15
        else if(UART0_RX==PTB16)
            PORTB_PCR16 = PORT_PCR_MUX(0x3);     //enable UART0_RXD on PTB16
        else if(UART0_RX==PTD6)
            PORTD_PCR6 = PORT_PCR_MUX(0x3);      //enable UART0_RXD on PTD6
        else
            assert_failed(__FILE__, __LINE__);   

        if(UART0_TX==PTA2)
            PORTA_PCR2 = PORT_PCR_MUX(0x2);     //enable UART0_TXD on PTA2
        else if(UART0_TX==PTA14)
            PORTA_PCR14 = PORT_PCR_MUX(0x3);    //enable UART0_TXD on PTA14
        else if(UART0_TX==PTB17)
            PORTB_PCR17 = PORT_PCR_MUX(0x3);    //enable UART0_TXD on PTB17
        else if(UART0_TX==PTD7)
            PORTD_PCR7 = PORT_PCR_MUX(0x3);     //enable UART0_TXD on PTD7
        else
            assert_failed(__FILE__, __LINE__);  


        SIM_SCGC4 |= SIM_SCGC4_UART0_MASK;      //enable UARTn clock
        break;

    case UART1:
        if(UART1_RX==PTC3)
            PORTC_PCR3 = PORT_PCR_MUX(0x3);     
        else if(UART1_RX==PTE1)
            PORTE_PCR1 = PORT_PCR_MUX(0x3);     
        else
            assert_failed(__FILE__, __LINE__);  

        if(UART1_TX==PTC4)
            PORTC_PCR4 = PORT_PCR_MUX(0x3);     
        else if(UART1_TX==PTE0)
            PORTE_PCR0 = PORT_PCR_MUX(0x3);     
        else
            assert_failed(__FILE__, __LINE__);  

        SIM_SCGC4 |= SIM_SCGC4_UART1_MASK;
        break;

    case UART2:
        PORTD_PCR3 = PORT_PCR_MUX(0x3);         
        PORTD_PCR2 = PORT_PCR_MUX(0x3);         
        SIM_SCGC4 |= SIM_SCGC4_UART2_MASK;
        break;

    case UART3:
        if(UART3_RX==PTB10)
            PORTB_PCR10 = PORT_PCR_MUX(0x3);     
        else if(UART3_RX==PTC16)
            PORTC_PCR16 = PORT_PCR_MUX(0x3);     
        else if(UART3_RX==PTE5)
            PORTE_PCR5 = PORT_PCR_MUX(0x3);      
        else
            assert_failed(__FILE__, __LINE__);               

        if(UART3_TX==PTB11)
            PORTB_PCR11 = PORT_PCR_MUX(0x3);     
        else if(UART3_TX==PTC17)
            PORTC_PCR17 = PORT_PCR_MUX(0x3);    
        else if(UART3_TX==PTE4)
            PORTE_PCR4 = PORT_PCR_MUX(0x3);     
        else
            assert_failed(__FILE__, __LINE__);                

        SIM_SCGC4 |= SIM_SCGC4_UART3_MASK;
        break;

    case UART4:
        if(UART4_RX==PTC14)
            PORTC_PCR14 = PORT_PCR_MUX(0x3);    
        else if(UART4_RX==PTE25)
            PORTE_PCR25 = PORT_PCR_MUX(0x3);    
        else
            assert_failed(__FILE__, __LINE__);                 

        if(UART4_TX==PTC15)
            PORTC_PCR15 = PORT_PCR_MUX(0x3);    
        else if(UART4_TX==PTE24)
            PORTE_PCR24 = PORT_PCR_MUX(0x3);     
        else
            assert_failed(__FILE__, __LINE__);                  

        SIM_SCGC1 |= SIM_SCGC1_UART4_MASK;
        break;

    case UART5:
        if(UART5_RX==PTD8)
            PORTD_PCR8 = PORT_PCR_MUX(0x3);     
        else if(UART5_RX==PTE9)
            PORTE_PCR9 = PORT_PCR_MUX(0x3);     
        else
            assert_failed(__FILE__, __LINE__);                

        if(UART5_TX==PTD9)
            PORTD_PCR9 = PORT_PCR_MUX(0x3);     
        else if(UART5_TX==PTE8)
            PORTE_PCR8 = PORT_PCR_MUX(0x3);     
        else
            assert_failed(__FILE__, __LINE__);                  

        SIM_SCGC1 |= SIM_SCGC1_UART5_MASK;
        break;
    default:
        break;
    }

    //disable tx and rx in initialization
    UART_C2_REG(UARTx[uartn]) &= ~(UART_C2_TE_MASK  | UART_C2_RE_MASK );

    //8-bit data, none parity
    UART_C1_REG(UARTx[uartn]) = 0;	//default setting

	//parity config
	uart_parity(uartn, parity);
	
    //calculate baud rate, UART0, 1 use core clock, other UARTs use peripheral bus clock
    if ((uartn == UART0) | (uartn == UART1))
        sysclk=core_clk_khz*1000;      
    else
        sysclk=bus_clk_khz*1000;  

    //set baud rate
    sbr = (uint16)(sysclk/(baud << 4));

    /* Save off the current value of the UARTx_BDH except for the SBR field */
    temp = UART_BDH_REG(UARTx[uartn]) & ~(UART_BDH_SBR(0x1F));

    UART_BDH_REG(UARTx[uartn]) = temp |  UART_BDH_SBR(((sbr & 0x1F00) >> 8));
    UART_BDL_REG(UARTx[uartn]) = (uint8)(sbr & UART_BDL_SBR_MASK);

    //brfa = (((sysclk*32)/(baud * 16)) - (sbr * 32));
    brfa = (((sysclk<<5)/(baud <<4)) - (sbr <<5));

    /* Save off the current value of the UARTx_C4 register except for the BRFA field */
    temp = UART_C4_REG(UARTx[uartn]) & ~(UART_C4_BRFA(0x1F));

    UART_C4_REG(UARTx[uartn]) = temp |  UART_C4_BRFA(brfa);

    /* enable rx and tx */
    UART_C2_REG(UARTx[uartn]) |= (UART_C2_TE_MASK | UART_C2_RE_MASK );
}

/*******************************************************************************
Procedure     :	uart_parity
Arguments     : [in]uartn: UART number (UART0~UART5)
                [in]parity: parity setting, ('N' 'E' or 'O')
Return	      : Null
Description   : UART parity configuration.
*******************************************************************************/
void uart_parity (UARTn uartn, uint8 parity)
{
	switch (parity)
	{
		case  'N':
		case  'n':
			//if disable parity, must select 8-bit mode
			UART_C1_REG(UARTx[uartn]) &= ~(UART_C1_M_MASK);
			UART_C1_REG(UARTx[uartn]) &= ~(UART_C1_PE_MASK);
			break;
			
		case  'E':
		case  'e':
			//if enable parity, must select 9-bit mode
			UART_C1_REG(UARTx[uartn]) |= (UART_C1_M_MASK);
			UART_C1_REG(UARTx[uartn]) |= (UART_C1_PE_MASK);
			UART_C1_REG(UARTx[uartn]) &= ~(UART_C1_PT_MASK);
			break;
			
		case  'O':
		case  'o':
			//if enable parity, must select 9-bit mode
			UART_C1_REG(UARTx[uartn]) |= (UART_C1_M_MASK);
			UART_C1_REG(UARTx[uartn]) |= (UART_C1_PE_MASK | UART_C1_PT_MASK);
			break;

		default:
			break;
	}
}

/*******************************************************************************
Procedure     :	uart_getchar
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : char be received 
Description	  : waiting for a port untill to receive a char.
*******************************************************************************/
char uart_getchar (UARTn uartn)
{
    /* Wait until character has been received */
    while (!(UART_S1_REG(UARTx[uartn]) & UART_S1_RDRF_MASK));

    /* Return the 8-bit data from the receiver */
    return UART_D_REG(UARTx[uartn]);
}

/*******************************************************************************
Procedure     :	uart_pendchar
Arguments 	  : [in]uartn: UART number (UART0~UART5)
                [out]ch: destination pointer to save the received char  
Return		  : 0- receiving failed
                1- successfully received a char
Description	  : waiting for a port in a  limited time to receive a byte.
*******************************************************************************/
char uart_pendchar (UARTn uartn,char * ch)
{
    uint32 i=0;

    while(++i<0xffffff) //time limit
    {
        if(UART_S1_REG(UARTx[uartn]) & UART_S1_RDRF_MASK)         
        {
            *ch  =   UART_D_REG(UARTx[uartn]);                   
            return  1;                                            
        }
    }

    *ch=0;                                                       
    return 0;                                                  
}


/*******************************************************************************
Procedure     :	uart_pendstr
Arguments 	  : [in]uartn: UART number (UART0~UART5)
                [out]str: destination pointer to save the received string  
Return		  : 0- receiving failed
                1- successfully received a string
Description	  : waiting for a port in a  limited time to receive a string.
*******************************************************************************/
char uart_pendstr (UARTn uartn,char * str)
{
    uint32 i=0;
    while(uart_pendchar(uartn,str+i++));

    return (i <= 1 ? 0:1);
}



/*******************************************************************************
Procedure     :	uart_pendchar
Arguments 	  : [in]uartn: UART number (UART0~UART5)
                [in]ch: char to be sent out  
Return		  : Null
Description	  : send a char.
Comment       : this routine will be called by printf  
*******************************************************************************/
void uart_putchar (UARTn uartn, char ch)
{
    //wait until send register empty
    while(!(UART_S1_REG(UARTx[uartn]) & UART_S1_TDRE_MASK));
    //send data
    UART_D_REG(UARTx[uartn]) = (uint8)ch;
}


/*******************************************************************************
Procedure     :	uart_query
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : 0- not received a char
                1- have received a char
Description	  : query whether a char has been received.
*******************************************************************************/
int uart_query (UARTn uartn)
{
    return (UART_S1_REG(UARTx[uartn]) & UART_S1_RDRF_MASK);
}

/*******************************************************************************
Procedure     :	uart_sendN
Arguments 	  : [in]uartn: UART number (UART0~UART5)
                [in]buff: pointer to the buffer to being sent out
                [in]len: size of data to being sent out
Return		  : Null
Description	  : sned a string by appointed size.
*******************************************************************************/
void uart_sendN (UARTn uartn,uint8* buff,uint16 len)
{
    int i;
    for(i=0;i<len;i++)
    {
	uart_putchar(uartn,buff[i]);
    }
}

/*******************************************************************************
Procedure     :	uart_sendStr
Arguments 	  : [in]uartn: UART number (UART0~UART5)
                [in]str: head pointer of the string
Return		  : Null
Description	  : sned a string that is ended by a end char(0x00).
*******************************************************************************/
void uart_sendStr (UARTn uartn,const uint8* str)
{
    while(*str)
    {
        uart_putchar(uartn,*str++);
    }
}

/*******************************************************************************
Procedure     :	uart_irq_EN
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : enable interruption of receiving.
*******************************************************************************/
void uart_irq_EN(UARTn uartn)
{
    UART_C2_REG(UARTx[uartn]) |= UART_C2_RIE_MASK;      
    enable_irq((uartn<<1)+45);			           
}


/*******************************************************************************
Procedure     :	uart_irq_DIS
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : disable UART interruption.
*******************************************************************************/
void uart_irq_DIS(UARTn uartn)
{
    UART_C2_REG(UARTx[uartn]) &= ~(UART_C2_RIE_MASK | UART_C2_TIE_MASK | UART_C2_TCIE_MASK);     
    disable_irq((uartn<<1)+45);			            
}



/*******************************************************************************
Procedure     :	UartInit
Arguments     : [in]uartn: UART number (UART0~UART5)
                [in]baud: wanted baud rate
                [in]parity: parity setting, ('N' 'E' or 'O')
                [in]txSpace: setting of min space time between frame (unit: ms)
Return	      : TRUE-Initialization success
				FALSE-Initialization failed (invalid input)
Description   : Initialize UART, set baudrate.
*******************************************************************************/
uint8 UartInit(UARTn uartn, uint32 baud, uint8 parity, uint16 txSpace)
{
	if (uartn > UART5)
		return FALSE;
	
    uart_init(uartn, baud, parity);
	
    UartIOSet(uartn);
    
	if (UartRxBufSet(uartn) == FALSE)
		return FALSE;
	
	if (UartTxBufSet(uartn) == FALSE)
		return FALSE;
    
    RTxCtrlInit(uartn, txSpace);
    
    uart_irq_EN(uartn);    

	return TRUE;
}

/*******************************************************************************
Procedure     :	UartIOSet
Arguments     : [in]uartn: UART number (UART0~UART5)
Return	      : None
Description   : Set IOs for the UART.
*******************************************************************************/
void UartIOSet(UARTn uartn)
{
    switch (uartn)
    {
        case  UART1:
          Uart1IOSet();
		  break;

		default:
          break;
    }
}

/*******************************************************************************
Procedure     :	UartRxBufSet
Arguments     : [in]uartn: UART number (UART0~UART5)
Return	      : pointer to the buffer if successful,
				or return FALSE if failed
Description   : Set ring RX buffer for UART.
*******************************************************************************/
void* UartRxBufSet(UARTn uartn)
{
    switch (uartn)
    {
        case  UART1:
            return (void*)(pRxBuf[UART1] = (CIRCLEBUF*)Uart1RxBufSet());
			
		default:
          return FALSE;
    }
}

/*******************************************************************************
Procedure     :	UartTxBufSet
Arguments     : [in]uartn: UART number (UART0~UART5)
Return	      : pointer to the buffer if successful,
				or return FALSE if failed
Description   : Set ring TX buffer for UART.
*******************************************************************************/
void* UartTxBufSet(UARTn uartn)
{
    switch (uartn)
    {
        case  UART1:
          return (void*)(pTxBuf[UART1] = (CIRCLEBUF*)Uart1TxBufSet());

		default:
          return FALSE;
    }
}

/*******************************************************************************
Procedure     :	RTxCtrlInit
Arguments     : [in]uartn: UART number (UART0~UART5)
                [in]txSpace: setting of min space time between frame (unit: ms)
Return	      : Null
Description   : Initialize RX and TX control strcture for UART.
*******************************************************************************/
void RTxCtrlInit(UARTn uartn, uint16 txSpace)
{
    switch (uartn)
    {
        case  UART1:
          pRTxCtrl[UART1] = (RTX_CTRL*)Uart1RTxCtrlInit();
          break;
		  
		default:
			return;
    }
	pRTxCtrl[uartn]->lastRxTime = GetGtime();
	pRTxCtrl[uartn]->lastTxTime = GetGtime();
	pRTxCtrl[uartn]->txSpaceSet = txSpace;
	pRTxCtrl[uartn]->txing = FALSE;
}

/*******************************************************************************
Procedure     :	UartOnPreTx
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : Controls before TX.
*******************************************************************************/
inline void UartOnPreTx(UARTn uartn)
{
	pRTxCtrl[uartn]->pfPreTx();
}

/*******************************************************************************
Procedure     :	UartOnPostTx
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : Controls after TX finish.
*******************************************************************************/
inline void UartOnPostTx(UARTn uartn)
{
	pRTxCtrl[uartn]->pfPostTx();
}

/*******************************************************************************
Procedure     :	UartPollOnTxc
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : Controls after TX completion on polling mode.
*******************************************************************************/
void UartPollOnTxc(UARTn uartn)
{
#if 1 //more strict: must wait until TXC, so 'lastTxTime' is more rigorous
//#ifdef UART_USE_RT_SWITCH
    //wait until TX completion
    while(!(UART_S1_REG(UARTx[uartn]) & UART_S1_TC_MASK));
	pRTxCtrl[uartn]->pfPostTx();
//#endif

#else //more efficient: if not use RT switch, like RS232 condition, not wait to TXC
	switch (uartn)
	{
        case  UART1:
          Uart1PollOnTxc();
          break;
		  
		default:
			return;
	}
#endif
}

/*******************************************************************************
Procedure     :	UartIsTxIdle
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : TRUE- TX is idle (line is idle and TX buffer is empty)
				FALSE- TX is not idle
Description	  : check if UARTn in idle state. 
Comment		  : TX line is idle and TX buffer is empty.
*******************************************************************************/
BOOL8 UartIsTxIdle(UARTn uartn)
{
    if (CBufIsEmpty((CIRCLEBUF*)pTxBuf[uartn]) 
		&& (!(pRTxCtrl[uartn]->txing))
		&& ((!pRTxCtrl[uartn]->txSpaceSet) 
			|| (GetInterval(pRTxCtrl[uartn]->lastTxTime) > pRTxCtrl[uartn]->txSpaceSet))) 
    {
 		return TRUE;
   	}  
	
    return FALSE;
}

/*******************************************************************************
Procedure     :	UartLoopUntilTxIdle
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : Polling check TX state, until it comes to idle status.
*******************************************************************************/
inline void UartLoopUntilTxIdle(UARTn uartn)
{
	while (!UartIsTxIdle(uartn));
}

/*******************************************************************************
Procedure     :	UartIsTxLineIdle
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : TRUE- TX line is idle 
				FALSE- TX line is not idle
Description	  : check if UARTn transmit line in idle state.
Comment		  : only TX line is idle
*******************************************************************************/
BOOL8 UartIsTxLineIdle(UARTn uartn)
{
    if (!(pRTxCtrl[uartn]->txing) 
		&& ((!pRTxCtrl[uartn]->txSpaceSet) 
			|| (GetInterval(pRTxCtrl[uartn]->lastTxTime) > pRTxCtrl[uartn]->txSpaceSet))) 
    {
 		return TRUE;
   	}  
	
    return FALSE;
}

/*******************************************************************************
Procedure     :	UartLoopUntilTxLineIdle
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : Polling check TX line state, until it comes to idle status.
*******************************************************************************/
inline void UartLoopUntilTxLineIdle(UARTn uartn)
{
	while (!UartIsTxLineIdle(uartn));
}

/*******************************************************************************
Procedure     :	UartGetLastRxTime
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Time of last data received.
Description	  : Get received time of last data.
*******************************************************************************/
inline uint32 UartGetLastRxTime(UARTn uartn)
{
	return pRTxCtrl[uartn]->lastRxTime;
}

/*******************************************************************************
Procedure     :	UartGetLastTxTime
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Time of last data transmited.
Description	  : Get time of last data transmited.
*******************************************************************************/
inline uint32 UartGetLastTxTime(UARTn uartn)
{
	return pRTxCtrl[uartn]->lastTxTime;
}

/*******************************************************************************
Procedure     :	UartGetRxCnt
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Quantity of RX data.
Description	  : Get quantity of RX data.
*******************************************************************************/
inline uint16 UartGetRxCnt(UARTn uartn)
{
	return pRxBuf[uartn]->dataCnt;
}

/*******************************************************************************
Procedure     :	UartGetTxSpareSize
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : spare size of TX buffer
Description	  : Get spare size of TX buffer.
*******************************************************************************/
inline uint16 UartGetTxSpareSize(UARTn uartn)
{
	return CBUF_SPARE_SIZE(pRxBuf[uartn]);
}

/*******************************************************************************
Procedure     :	UartGetRxData
Arguments 	  : [in]uartn: UART number (UART0~UART5)
				[out]pDes: pointer of destination to store output data 
				[in]len: amount of data to be get out
						0- means get all RX data out
Return		  : count of data actually be get out. 
				0-failed, buffer is empty
Description	  : Get data out from Rx buffer to a appointed destination.
*******************************************************************************/
inline uint16 UartGetRxData(UARTn uartn, uint8* pDes, uint16 len)
{
	return CBufGetData((CIRCLEBUF*)pRxBuf[uartn], pDes, len);
}

/*******************************************************************************
Procedure     :	UartPutTxData
Arguments 	  : [in]uartn: UART number (UART0~UART5)
				[in]pData: head pointer of data to be send
				[in]len: length of data to be send
Return		  : len-count of data actually be put in, or 
				0-failed, buffer is full
Description	  : Put(copy) data into TX buffer, wait to be send out.
*******************************************************************************/
inline uint16 UartPutTxData(UARTn uartn, uint8* pData, uint16 len)
{
	return CBufPutData((CIRCLEBUF*)pTxBuf[uartn], pData, len);
}

/*************************************************************************
Function Name :	UartTxStart
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : TRUE-success
				FALSE-failed
Description	  : start sending data in TX buffer, enable interrupt mode.
             	if use RS485, switch to RS485_TX mode, and send in interrupt mode.
**************************************************************************/
uint8 UartTxStart(UARTn uartn)
{
	if (CBufIsEmpty((CIRCLEBUF*)pTxBuf[uartn]))
		return FALSE;

	if (pRTxCtrl[uartn]->txing)
		return FALSE;

	pRTxCtrl[uartn]->txing	= TRUE;
	pRTxCtrl[uartn]->pfPreTx();

	while (!(UART_S1_REG(UARTx[uartn]) & UART_S1_TDRE_MASK)); //unnecessary	
	CBufGetChar((CIRCLEBUF*)pTxBuf[uartn], (uint8*)&UART_D_REG(UARTx[uartn]));
	
	pRTxCtrl[uartn]->lastTxTime = GetGtime();
	
	UART_TI_EN(uartn); //enable transmitter interrupt
	return TRUE;
}

/*************************************************************************
Function Name :	UartTxBlock
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : TRUE-success
				FALSE-failed
Description	  : Sending out all data in TX buffer, by block mode.
Comment		  :	block mode: not use interruption
**************************************************************************/
uint8 UartTxBlock(UARTn uartn)
{
	if (CBufIsEmpty((CIRCLEBUF*)pTxBuf[uartn]))
		return FALSE;

	if (pRTxCtrl[uartn]->txing)
		return FALSE;

	pRTxCtrl[uartn]->txing	= TRUE;
	pRTxCtrl[uartn]->pfPreTx();
	
	while (!CBufIsEmpty((CIRCLEBUF*)pTxBuf[uartn]))
	{
		while (!(UART_S1_REG(UARTx[uartn]) & UART_S1_TDRE_MASK)); 
		CBufGetChar((CIRCLEBUF*)pTxBuf[uartn], (uint8*)&UART_D_REG(UARTx[uartn]));
		pRTxCtrl[uartn]->lastTxTime = GetGtime();
	}
	
	UartPollOnTxc(uartn);
	pRTxCtrl[uartn]->lastTxTime = GetGtime();
	pRTxCtrl[uartn]->txing	= FALSE;	
	return TRUE;
}

/*************************************************************************
Function Name :	UartTxPolling
Arguments 	  : [in]uartn: UART number (UART0~UART5)
				[in]pData: head pointer of data to be send
				[in]len: length of data to be send
Return		  : Null
Description	  : send data directly in polling way, not use circle TX buffer.
Comment		  :	Sending in polling mode has a lower priority compare with 
				transmitting data in TX buffer. Mainly used for debug.
				This function should not be called in ISR.
**************************************************************************/
void UartTxPolling(UARTn uartn, uint8* pData, uint16 len)
{
	if (!len)
		return;

	/*	For safety, if there are existing data in TX buffer but have not started 
	 *	transmitting yet, call 'UartTxStart' to start transmission first and 
	 *	then wait until TX idle, then start this transmission.
	 */
	//UartTxStart(uartn);
	
	UartLoopUntilTxLineIdle(uartn); 
	
	pRTxCtrl[uartn]->txing	= TRUE;
	pRTxCtrl[uartn]->pfPreTx();
	
	while (len--)
	{
		while (!(UART_S1_REG(UARTx[uartn]) & UART_S1_TDRE_MASK)); 
		UART_D_REG(UARTx[uartn]) = *pData++;
		pRTxCtrl[uartn]->lastTxTime = GetGtime();
	}
	
	UartPollOnTxc(uartn);
	pRTxCtrl[uartn]->lastTxTime = GetGtime();
	pRTxCtrl[uartn]->txing	= FALSE;	

	//for safety of following transmission
	UartLoopUntilTxLineIdle(uartn);
}


/*************************************************************************
Function Name :	UartPutchar
Arguments 	  : [in]uartn: UART number (UART0~UART5)
				[in]ch: character be send out
Return		  : It returns the character, or EOF in case an error occurred. 
Description	  : Send input char out by UART, wait until TX complete.
				Mainly used for debug print.
**************************************************************************/
int UartPutchar(UARTn uartn, char ch)
{
#if 1
	//while (pRTxCtrl[uartn]->txing);
	if (pRTxCtrl[uartn]->txing)
	{
		UartLoopUntilTxLineIdle(uartn);
	}
#endif

	if (ch == '\n')
	{
    	UartPutchar(uartn, '\r');
	}
	
	pRTxCtrl[uartn]->txing	= TRUE;	
	pRTxCtrl[uartn]->pfPreTx();
	
	while (!(UART_S1_REG(UARTx[uartn]) & UART_S1_TDRE_MASK)); 
	UART_D_REG(UARTx[uartn]) = ch;
	
	UartPollOnTxc(uartn);
	pRTxCtrl[uartn]->lastTxTime = GetGtime();
	pRTxCtrl[uartn]->txing	= FALSE;
	
	return ch;
}

/*******************************************************************************
Procedure     :	UartIsrOnRDRF
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : Interrupt service routine on RDRF(receive data register full).
*******************************************************************************/
void UartIsrOnRDRF(UARTn uartn)
{
	pRTxCtrl[uartn]->lastRxTime = GetGtime();
	CBufPutChar((CIRCLEBUF*)pRxBuf[uartn], UART_D_REG(UARTx[uartn]));
}

/*******************************************************************************
Procedure     :	UartIsrOnTDRE
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : Interrupt service routine on RDRF(receive data register full).
*******************************************************************************/
void UartIsrOnTDRE(UARTn uartn)
{
	if (!CBufIsEmpty((CIRCLEBUF*)pTxBuf[uartn]))
	{
		CBufGetChar((CIRCLEBUF*)pTxBuf[uartn], (uint8*)&UART_D_REG(UARTx[uartn]));
	}
	if (CBufIsEmpty((CIRCLEBUF*)pTxBuf[uartn]))
	{
		UART_TI_DIS(uartn);
		UART_TCI_EN(uartn);
	}
	pRTxCtrl[uartn]->lastTxTime = GetGtime();
}

/*******************************************************************************
Procedure     :	UartIsrOnTC
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : Interrupt service routine on RDRF(receive data register full).
*******************************************************************************/
void UartIsrOnTC(UARTn uartn)
{
	UART_TI_TCI_DIS(uartn);
	pRTxCtrl[uartn]->pfPostTx();
	pRTxCtrl[uartn]->lastTxTime = GetGtime();
	pRTxCtrl[uartn]->txing = FALSE;
}

/*******************************************************************************
Procedure     :	UartIsr
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : Interrupt service routine for UART status sources.
*******************************************************************************/
void UartIsr(UARTn uartn)
{ 
	//DisableInterrupts;
	
	uint8	s1 = UART_S1_REG(UARTx[uartn]);
	uint8	c2 = UART_C2_REG(UARTx[uartn]);
	
	if (s1 & UART_S1_RDRF_MASK)
	{
		UartIsrOnRDRF(uartn);
	}
	
	if ((c2 & UART_C2_TIE_MASK) && (s1 & UART_S1_TDRE_MASK))
	{
		UartIsrOnTDRE(uartn);
	}
	
	else if ((c2 & UART_C2_TCIE_MASK) && (s1 & UART_S1_TC_MASK))
	{
		UartIsrOnTC(uartn);
	}
	
    //EnableInterrupts;		    
}

/*******************************************************************************
Procedure     :	UartRxSrv
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : UART background service routine for RX.
*******************************************************************************/
void UartRxSrv(UARTn uartn)
{
	/*	If use UART Rx FIFO, data insufficient in FIFO to trigger RDFR interruption 
	 *	can be got into Rx buffer here.
	 */
}

/*******************************************************************************
Procedure     :	UartTxSrv
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : UART background service routine for TX.
*******************************************************************************/
void UartTxSrv(UARTn uartn)
{
	//if there is data wait to be send in TX buffer, check to start TX
	if (!CBufIsEmpty((CIRCLEBUF*)pTxBuf[uartn]))
	{
		if (UartIsTxLineIdle(uartn))
		{
			UartTxStart(uartn);
		}
	}
}

/*******************************************************************************
Procedure     :	UartSrv
Arguments 	  : [in]uartn: UART number (UART0~UART5)
Return		  : Null
Description	  : UART main service routine running in background.
*******************************************************************************/
void UartSrv(UARTn uartn)
{
	UartRxSrv(uartn);
	
	UartTxSrv(uartn);
}


