/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		uart1.h
** Descriptions:	UART1 specific driver
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-09-27
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef __UART1_H__
#define __UART1_H__

#ifdef __cplusplus
extern "C" 	{
#endif

  
/******************************macro definition********************************/
#define	UART1_USE_RT_SWITCH


//UART transmission format defines
#define  UART1_DFT_BAUD	      	115200	//baud rate in bps, BAUD_MIN<=UART_BPS<=BAUD_MAX
#define  UART1_DFT_PARITY     	'N'     //define parity check mode: 'N'-None, 'E'-Even, 'O'-Odd.

  
/*******************************data definition********************************/


/****************************variable declaration******************************/


/*******************************macro operation********************************/


/****************************function declaration******************************/
extern  uint8 	Uart1Init(uint32 baud, uint8 parity, uint16 txSpace);                     
extern  void 	Uart1IOSet(void);                     
extern  void 	Uart1PollOnTxc(void);                     
extern  void*	Uart1RxBufSet(void);                     
extern  CIRCLEBUF*	Uart1TxBufSet(void);                     
extern  RTX_CTRL* 	Uart1RTxCtrlInit(void);                     


#ifdef __cplusplus 
} 
#endif 

#endif /* __UART1_H__ */

