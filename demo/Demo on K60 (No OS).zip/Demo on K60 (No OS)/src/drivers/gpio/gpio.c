/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		gpio.c
** Descriptions:	GPIO driver
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#include "system.h"
#include "gpio.h"


/*************************extern variable declaration**************************/


/*************************extern function declaration**************************/


/****************************variable declaration******************************/
//define 5 pointer array to save address of GPIOx
volatile struct GPIO_MemMap *GPIOx[5]={PTA_BASE_PTR,PTB_BASE_PTR,PTC_BASE_PTR,PTD_BASE_PTR,PTE_BASE_PTR};
volatile struct PORT_MemMap *PORTX[5]={PORTA_BASE_PTR,PORTB_BASE_PTR,PORTC_BASE_PTR,PORTD_BASE_PTR,PORTE_BASE_PTR};


/****************************function declaration******************************/


/*******************************************************************************
Procedure     :	gpio_init
Arguments 	  : [in]portx: port number(PORTA,PORTB,PORTC,PORTD,PORTE)
                [in]n: pin number
                [in]cfg: direction of pin, 0-input, 1-output
                [in]data: initial state of output pin, 0-low level, 1-high level (useless for input)
Return		  : Null
Description	  : Initialize GPIO.
*******************************************************************************/
void gpio_init(PORTx portx, uint8 n,GPIO_CFG cfg,uint8 data)
{
    ASSERT( (n < 32u) && (data < 2u) );           

    //pin function selection
    PORT_PCR_REG(PORTX[portx],n) = (0|PORT_PCR_MUX(1)/*|cfg*/);

    //direction config
    if(((cfg&0x01) == GPI) || (cfg == GPI_UP) || (cfg == GPI_UP_PF))
    {
        GPIO_PDDR_REG(GPIOx[portx]) &= ~(1<<n); //set  as input
    }
    else
    {
        GPIO_PDDR_REG(GPIOx[portx]) |= (1<<n); //set as output
        if(data == 1) 
        {
            GPIO_SET(portx,n,1); //output 1
        }
        else
        {
            GPIO_SET(portx,n,0); //output 0
        }
    }
}

/*******************************************************************************
Procedure     :	gpio_set
Arguments 	  : [in]portx: port number(PORTA,PORTB,PORTC,PORTD,PORTE)
                [in]n: pin number
                [in]data: state of output pin to be set, 0-low level, 1-high level 
Return		  : Null
Description	  : set state of output pin.
*******************************************************************************/
void gpio_set(PORTx portx, uint8 n, uint8 data)
{
    ASSERT( (n < 32u) && (data < 2u) );   

    if(data == 1)               
        GPIO_SET(portx,n,1);    //GPIO_PDOR_REG(PORTx) |= (1<<n);
    else
        GPIO_SET(portx,n,0);    //GPIO_PDOR_REG(PORTx) &= ~(1<<n);
}

/*******************************************************************************
Procedure     :	gpio_turn
Arguments 	  : [in]portx: port number(PORTA,PORTB,PORTC,PORTD,PORTE)
                [in]n: pin number
Return		  : Null
Description	  : Inverse state of output pin.
*******************************************************************************/
void gpio_turn(PORTx portx, uint8 n)
{
    ASSERT( n < 32u );    
    GPIO_TURN(portx,n);
}

/*******************************************************************************
Procedure     :	gpio_get
Arguments 	  : [in]portx: port number(PORTA,PORTB,PORTC,PORTD,PORTE)
                [in]n: pin number
Return		  : Null
Description	  : get pin state.
*******************************************************************************/
uint8 gpio_get(PORTx portx,uint8 n)         
{
    ASSERT( n < 32u );      
    return GPIO_Get(portx,n);
}
