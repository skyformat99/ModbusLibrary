/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		gpio.h
** Descriptions:	head file for GPIO driver
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef __GPIO_H__
#define __GPIO_H__

#include "gpio_cfg.h"


#ifdef __cplusplus
extern "C" 	{
#endif


/******************************macro definition********************************/
#define HIGH  1u
#define LOW   0u

  
/*******************************data definition********************************/
//enumeration definition of prot number
typedef enum PORTx
{
    PORTA,
    PORTB,
    PORTC,
    PORTD,
    PORTE
}PORTx;

//enumeration definition of prot direction feature. values can't be changed
typedef enum GPIO_CFG
{   
    GPI =0,         //input(in GPIOx_PDDRn, 0 means input, while 1 means output)
    GPO =1,         //output 

    GPI_DOWN =0x02, //input with pull-down (require: PE=1, PS=0 in PORTx_PCRn) 
    GPI_UP =0x03,   //input with pull-up (require: PE=1, PS=1 in PORTx_PCRn)      
    GPI_PF =0x10,   //input with passive filter. filter range: 10 MHz ~ 30 MHz, unsupport high-speed interface(>=2MHz)  (0b10000: Passive Filter Enable)  
    GPI_DOWN_PF =GPI_DOWN | GPI_PF, //input with pull-down and passive filter
    GPI_UP_PF =GPI_UP | GPI_PF,     //input with pull-up and passive filter

    GPO_HDS =0x41,  //output with high drive strength (0b100 0001: High drive strength)  
    GPO_SSR =0x05,  //output with slow slew rate (0b101: Slow slew rate)
    GPO_HDS_SSR = GPO_HDS | GPO_SSR,//output with high drive strength and slow slew rate
}GPIO_CFG;  


/****************************variable declaration******************************/
extern  volatile struct GPIO_MemMap *GPIOx[5];
extern  volatile struct PORT_MemMap *PORTX[5];


/*********************for internal usage macro operation***********************/
#define GPIO_SET_1(PORTx,n)             GPIO_PDOR_REG(GPIOx[(PORTx)]) |= (1<<(n))       //set high output, e.g. GPIO_SET_1(PORTA,1)  PA1 output at high 
#define GPIO_SET_0(PORTx,n)             GPIO_PDOR_REG(GPIOx[(PORTx)]) &= ~(1<<(n))      //set low output, e.g. GPIO_SET_0(PORTA,1)  PA1 output at low


/*********************for external usage macro operation***********************/
#define GPIO_SET(PORTx,n,x)             GPIO_SET_##x((PORTx),(n))                       //set output at level 'x' (x=0 or 1), e.g. GPIO_SET(PORTA,1,1)  PA1output at high 
#define GPIO_TURN(PORTx,n)              (GPIO_PDOR_REG(GPIOx[(PORTx)]) ^= (1<<(n)))     //inverse output level
#define GPIO_Get(PORTx,n)               ((GPIO_PDIR_REG(GPIOx[(PORTx)])>>(n)) & 0x1)    //get input state
#define GPIO_INVERSE(PORTx,n)           (GPIO_PTOR_REG(GPIOx[(PORTx)]) |= (1<<(n)))     //inverse output level

//GPIO 1 bit operation
#define GPIO_SET_1bit(PORTx,n,data)     GPIO_PDOR_REG(GPIOx[(PORTx)]) = ((GPIO_PDOR_REG(GPIOx[(PORTx)]) & ~(0x1<<(n))) | (((data)&0x01)<<(n)))      //set output of 1 bit (n is pin number)
#define GPIO_DDR_1bit(PORTx,n,ddr)      GPIO_PDDR_REG(GPIOx[(PORTx)]) = ((GPIO_PDDR_REG(GPIOx[(PORTx)]) & ~(0x1<<(n))) | (((ddr)&0x01)<<(n)))       //set direction of 1 bit 
#define GPIO_GET_1bit(PORTx,n)          ((GPIO_PDIR_REG(GPIOx[(PORTx)])>>(n)) & 0x1)                                                                //get state of 1 bit 

//GPIO 2 bit operation
#define GPIO_SET_2bit(PORTx,n,data)     GPIO_PDOR_REG(GPIOx[(PORTx)]) = ((GPIO_PDOR_REG(GPIOx[(PORTx)]) & ~(0x3<<(n))) | (((data)&0x03)<<(n)))      //set 2 bits (n is lowest pin number)
#define GPIO_DDR_2bit(PORTx,n,ddr)      GPIO_PDDR_REG(GPIOx[(PORTx)]) = ((GPIO_PDDR_REG(GPIOx[(PORTx)]) & ~(0x3<<(n))) | (((ddr)&0x03)<<(n)))       //set direction of 2 bits 
#define GPIO_GET_2bit(PORTx,n)          ((GPIO_PDIR_REG(GPIOx[(PORTx)])>>(n)) & 0x3)                                                                //get state of 2 bits 

//GPIO 4 bit operation
#define GPIO_SET_4bit(PORTx,n,data)     GPIO_PDOR_REG(GPIOx[(PORTx)]) = ((GPIO_PDOR_REG(GPIOx[(PORTx)]) & ~(0xf<<(n))) | (((data)&0x0f)<<(n)))      //set 4 bits (n is lowest pin number)
#define GPIO_DDR_4bit(PORTx,n,ddr)      GPIO_PDDR_REG(GPIOx[(PORTx)]) = ((GPIO_PDDR_REG(GPIOx[(PORTx)]) & ~(0xf<<(n))) | (((ddr)&0x0f)<<(n)))       //set direction of 4 bits 
#define GPIO_GET_4bit(PORTx,n)          ((GPIO_PDIR_REG(GPIOx[(PORTx)])>>(n)) & 0xf)                                                                //get state of 4 bits 

//GPIO 6 bit operation
#define GPIO_SET_6bit(PORTx,n,data)     GPIO_PDOR_REG(GPIOx[(PORTx)]) = ((GPIO_PDOR_REG(GPIOx[(PORTx)]) & ~(0x3f<<(n))) | (((data)&0x3f)<<(n)))     //set 6 bits (n is lowest pin number)
#define GPIO_DDR_6bit(PORTx,n,ddr)      GPIO_PDDR_REG(GPIOx[(PORTx)]) = ((GPIO_PDDR_REG(GPIOx[(PORTx)]) & ~(0x3f<<(n))) | (((ddr)&0x03f)<<(n)))     //set direction of 6 bits 
#define GPIO_GET_6bit(PORTx,n)          ((GPIO_PDIR_REG(GPIOx[(PORTx)])>>(n)) & 0x3f)                                                               //get state of 6 bits 

//GPIO 8 bit operation
#define GPIO_SET_8bit(PORTx,n,data)     GPIO_PDOR_REG(GPIOx[(PORTx)]) = ((GPIO_PDOR_REG(GPIOx[(PORTx)]) & ~(0xff<<(n))) | (((data)&0xff)<<(n)))     //set 8 bits (n is lowest pin number)
#define GPIO_DDR_8bit(PORTx,n,ddr)      GPIO_PDDR_REG(GPIOx[(PORTx)]) = ((GPIO_PDDR_REG(GPIOx[(PORTx)]) & ~(0xff<<(n))) | (((ddr)&0x0ff)<<(n)))     //set direction of 8 bits 
#define GPIO_GET_8bit(PORTx,n)          ((GPIO_PDIR_REG(GPIOx[(PORTx)])>>(n)) & 0xff)                                                               //get state of 8 bits 

//GPIO 16 bit operation
#define GPIO_SET_16bit(PORTx,n,data)    GPIO_PDOR_REG(GPIOx[(PORTx)]) = ((GPIO_PDOR_REG(GPIOx[(PORTx)])&~(0xffff<<(n))) | (((data)&0xffff)<<(n)))   //set 16 bits (n is lowest pin number)
#define GPIO_DDR_16bit(PORTx,n,ddr)     GPIO_PDDR_REG(GPIOx[(PORTx)]) = ((GPIO_PDDR_REG(GPIOx[(PORTx)])& ~(0xffff<<(n))) | (((ddr)&0x0ffff)<<(n)))  //set direction of 16 bits
#define GPIO_GET_16bit(PORTx,n)         ((GPIO_PDIR_REG(GPIOx[(PORTx)])>>(n)) & 0xffff)                                                             //get state of 16 bits 

//GPIO 32 bit operation
#define GPIO_SET_32bit(PORTx,data)      GPIO_PDOR_REG(GPIOx[(PORTx)]) = (data)                                                                      //set 32 bits 
#define GPIO_DDR_32bit(PORTx,ddr)       GPIO_PDDR_REG(GPIOx[(PORTx)]) = (ddr)                                                                       //set direction of 32 bits 
#define GPIO_GET_32bit(PORTx)           GPIO_PDIR_REG(GPIOx[(PORTx)])                                                                               //get state of 32 bits 


/****************************function declaration******************************/
extern  void    gpio_init(PORTx, uint8 n, GPIO_CFG, uint8 data);//initialize GPIO
extern  void    gpio_set(PORTx, uint8 n, uint8 data);           //set state of output pin                                 
extern  void    gpio_turn(PORTx, uint8 n);                      //inverse output pin                              
extern  uint8   gpio_get(PORTx, uint8 n);                       //get state of input pin           


#ifdef __cplusplus 
} 
#endif 

#endif
