/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		pit.h
** Descriptions:	PIT related operations
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-07-01
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef __PIT_H__
#define __PIT_H__

#ifdef __cplusplus
extern "C" 	{
#endif

  
/******************************macro definition********************************/
#define PIT_CH0   (0)
#define PIT_CH1   (1)
#define	PIT_CH2   (2)
#define PIT_CH3   (3)
#define PIT_MAX   PIT_CH3


/*******************************data definition********************************/


/****************************variable declaration******************************/


/*******************************macro operation********************************/
#define PIT_IRQ_EN(idx)   	PIT_TCTRL(idx) |= PIT_TCTRL_TIE_MASK; enable_irq(PIT0_IRQn + idx)  
#define PIT_IRQ_DIS(idx)  	PIT_TCTRL(idx) &= ~PIT_TCTRL_TIE_MASK; disable_irq(PIT0_IRQn + idx)   
#define PIT_EN(idx)   		PIT_TCTRL(idx) |= PIT_TCTRL_TEN_MASK 
#define PIT_DIS(idx)   		PIT_TCTRL(idx) &= ~PIT_TCTRL_TEN_MASK 


/****************************function declaration******************************/
extern  void    PitInit(uint8 pit, uint32 time, uint8 enInt);                     
extern  void    ChainedPitInit(uint8 pit, uint32 ldVal, uint8 enInt);                     
extern  void    IntegralChainedPitInit(uint8 pit, uint32 prevTime, uint32 ldVal, uint8 enInt);                     

extern  void 	PIT0_IRQHandler(void);
extern  void 	PIT1_IRQHandler(void);
extern  void 	PIT2_IRQHandler(void);
extern  void 	PIT3_IRQHandler(void);

extern  void 	GtimeInit(void);
extern  uint32 	GetGtime(void);
extern  uint32 	GetInterval(uint32 prevTime);


#ifdef __cplusplus 
} 
#endif 

#endif 
