/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		pit.c
** Descriptions:	procedure of PIT operation
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-07-01
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#include "system.h"
#include "pit.h"


/*************************extern variable declaration**************************/


/*************************extern function declaration**************************/


/****************************variable declaration******************************/


/****************************function declaration******************************/


/*******************************************************************************
Procedure     :	PitInit
Arguments     : [in]pit: PIT number (PIT0~PIT3)
                [in]time: timer cycle, us
                [in]enInt: interrupt enable setting (TRUE of FALSE) 
Return	      : Null
Description   : Initialize and enable PIT, disable chain mode.
*******************************************************************************/
void PitInit(uint8 pit, uint32 time, uint8 enInt)
{	 
    ASSERT(pit <= PIT_MAX);

    // PIT clock enable:
    SIM_SCGC6 |= SIM_SCGC6_PIT_MASK;
    
    // enable the clock for PIT Timers:
    PIT_MCR = 1;

	// config the period of PIT
    PIT_LDVAL(pit) = (bus_clk_khz / 1000) * time - 1;

	// clear interruption flag
	PIT_TFLG(pit) |= PIT_TFLG_TIF_MASK;

	if (enInt)
	{
		// enable timer interrupt
		PIT_TCTRL(pit) = PIT_TCTRL_TIE_MASK; 
		enable_irq(PIT0_IRQn + pit);	
	}
	else
	{
		// disable timer interrupt
		PIT_TCTRL(pit) = 0; 
		disable_irq(PIT0_IRQn + pit);	
	}

	// enable timer
	PIT_TCTRL(pit) |= PIT_TCTRL_TEN_MASK;
}

/*******************************************************************************
Procedure     :	ChainedPitInit
Arguments     : [in]pit: PIT number (PIT0~PIT3)
                [in]ldVal: timer load value
                [in]enInt: interrupt enable setting (TRUE of FALSE) 
Return	      : Null
Description   : Initialize and enable PIT with chain mode enabled.
*******************************************************************************/
void ChainedPitInit(uint8 pit, uint32 ldVal, uint8 enInt)
{
    ASSERT((pit > PIT_CH0) && (pit <= PIT_MAX));
	
    // PIT clock enable:
    SIM_SCGC6 |= SIM_SCGC6_PIT_MASK;
    
    // enable the clock for PIT Timers:
    PIT_MCR = 1;

	// config the period of PIT
    PIT_LDVAL(pit) = ldVal;

	// clear interruption flag
	PIT_TFLG(pit) |= PIT_TFLG_TIF_MASK;

	if (enInt)
	{
		// enable timer interrupt
		PIT_TCTRL(pit) = PIT_TCTRL_TIE_MASK; 
		enable_irq(PIT0_IRQn + pit);	
	}
	else
	{
		// disable timer interrupt
		PIT_TCTRL(pit) = 0; 
		disable_irq(PIT0_IRQn + pit);	
	}

	// enable chain mode
	PIT_TCTRL(pit) |= 0x04;
	
	// enable timer
	PIT_TCTRL(pit) |= PIT_TCTRL_TEN_MASK;
}

/*******************************************************************************
Procedure     :	IntegralChainedPitInit
Arguments     : [in]pit: PIT number (PIT0~PIT3)
                [in]priorCyc: cycle of the previous timer, us
                [in]ldVal: timer load value
                [in]enInt: interrupt enable setting (TRUE of FALSE) 
Return	      : Null
Description   : Initialize and enable timer and with chain mode enabled, the prior
				timer is also initialized integrally with a given cycle.
Comment		  :	Interruption of prior timer is disabled.
*******************************************************************************/
void IntegralChainedPitInit(uint8 pit, uint32 priorCyc, uint32 ldVal, uint8 enInt)
{
	ChainedPitInit(pit, ldVal, enInt);

	PitInit(pit-1, priorCyc, FALSE);	
}


/*******************************************************************************
Procedure     :	PIT0_IRQHandler
Arguments 	  : Null
Return		  : Null
Description	  : PIT0 interruption service routine.
*******************************************************************************/
void PIT0_IRQHandler(void)
{ 
	PIT_TFLG0 |= PIT_TFLG_TIF_MASK; //clear interruption flag
	
  	//Todo: add your code here
}

/*******************************************************************************
Procedure     :	PIT1_IRQHandler
Arguments 	  : Null
Return		  : Null
Description	  : PIT1 interruption service routine.
*******************************************************************************/
void PIT1_IRQHandler(void)
{  
	PIT_TFLG1 |= PIT_TFLG_TIF_MASK; //clear interruption flag
	
  	//Todo: add your code here
}

/*******************************************************************************
Procedure     :	PIT2_IRQHandler
Arguments 	  : Null
Return		  : Null
Description	  : PIT2 interruption service routine.
*******************************************************************************/
void PIT2_IRQHandler(void)
{ 
	PIT_TFLG2 |= PIT_TFLG_TIF_MASK; //clear interruption flag
	
  	//Todo: add your code here
}

/*******************************************************************************
Procedure     :	PIT3_IRQHandler
Arguments 	  : Null
Return		  : Null
Description	  : PIT3 interruption service routine.
*******************************************************************************/
void PIT3_IRQHandler(void)
{ 
	PIT_TFLG3 |= PIT_TFLG_TIF_MASK; //clear interruption flag
	
  	//Todo: add your code here
}

/*******************************************************************************
Procedure     :	GtimeInit
Arguments 	  : Null
Return		  : Null
Description	  : Global timer initialization.
				Use PIT1 (chained with PIT0) to generate a free running global 
				timer by 1ms.
*******************************************************************************/
inline void GtimeInit(void)
{	
	IntegralChainedPitInit(PIT_CH1, 1000, 0xFFFFFFFF, FALSE);
}

/*******************************************************************************
Procedure     :	GetGtime
Arguments 	  : Null
Return		  : current global time value (unit: 1ms)
Description	  : Get current global time value. (unit: 1ms)
Comment		  :	precision: -1ms
*******************************************************************************/
inline uint32 GetGtime(void)
{	
	return (0xFFFFFFFF - PIT_CVAL1);
}

/*******************************************************************************
Procedure     :	GetInterval
Arguments 	  : [in]prevTime: previous reference time (unit: 1ms)
Return		  : the interval from reference time to current time (unit: 1ms)
Description	  : get the interval from reference time to current time. (unit: 1ms)
Comment		  :	range: 0~4294967295ms (1193 hours, or 49.71 days)
				precision: +-1ms, 
*******************************************************************************/
uint32 GetInterval(uint32 prevTime)
{	
	uint32 curTime;
	
	curTime = GetGtime();
	if (curTime < prevTime)
	{
		return (0xFFFFFFFF - prevTime + 1 + curTime);
	}
	return (curTime - prevTime);
}

