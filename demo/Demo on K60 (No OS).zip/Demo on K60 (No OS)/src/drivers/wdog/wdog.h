/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		wdog.h
** Descriptions:	Provide common watchdog module routines
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef __WDOG_H__
#define __WDOG_H__


#ifdef __cplusplus
extern "C" 	{
#endif


//function prototypes
extern	void 	wdog_unlock(void);
extern	void 	wdog_disable(void);
extern	void 	wdog_enable(uint32 msWDT);
extern	void 	wdog_refresh(void);


#ifdef __cplusplus 
} 
#endif 

#endif /* __WDOG_H__ */
