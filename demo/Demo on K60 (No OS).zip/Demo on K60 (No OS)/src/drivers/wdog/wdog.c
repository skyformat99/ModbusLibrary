/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		wdog.c
** Descriptions:	Provide common watchdog module routines
** Notes:		    Need to add more functionality. Right now it is just a disable
**                  routine since we know almost all projects will need that.     
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#include "system.h"
#include "wdog.h"
       

/******************************************************************************/
/*
 * Watchdog timer disable routine
 *
 * Parameters:
 * none
 */
void wdog_disable(void)
{
	/* First unlock the watchdog so that we can write to registers */
	wdog_unlock();
	
	/* Clear the WDOGEN bit to disable the watchdog */
	WDOG_STCTRLH &= ~WDOG_STCTRLH_WDOGEN_MASK;
}

/******************************************************************************/
/*
 * Watchdog timer unlock routine. Writing 0xC520 followed by 0xD928
 * will unlock the write once registers in the WDOG so they are writable
 * within the WCT period.
 *
 * Parameters:
 * none
 */
void wdog_unlock(void)
{
  /* NOTE: DO NOT SINGLE STEP THROUGH THIS FUNCTION!!! */
  /* There are timing requirements for the execution of the unlock. If
   * you single step through the code you will cause the CPU to reset.
   */

	/* This sequence must execute within 20 clock cycles, so disable
         * interrupts will keep the code atomic and ensure the timing.
         */
    DisableInterrupts;
	
	/* Write 0xC520 to the unlock register */
	WDOG_UNLOCK = 0xC520;
	
	/* Followed by 0xD928 to complete the unlock */
	WDOG_UNLOCK = 0xD928;
	
	/* Re-enable interrupts now that we are done */	
    EnableInterrupts;
}

/*******************************************************************************
Procedure     :	wdog_enable
Arguments 	  : [in]msWDT: WDT setting value (ms)
Return		  : Null
Description	  : Enable WDT by a specified time value.
*******************************************************************************/
void wdog_enable(uint32 msWDT)
{
	uint32 tova = 0;
	
	tova = bus_clk_khz / (((WDOG_PRESC & WDOG_PRESC_PRESCVAL_MASK) >> WDOG_PRESC_PRESCVAL_SHIFT) + 1) * msWDT;
	
	/* First unlock the watchdog so that we can write to registers */
	wdog_unlock();

	/* Set Timeout Value Register */
	WDOG_TOVALH = tova >> 16;
	WDOG_TOVALL = tova & 0xFFFF;
	
	/* Set the WDOGEN bit to enable the watchdog */
	WDOG_STCTRLH |= WDOG_STCTRLH_WDOGEN_MASK;
}

/*******************************************************************************
Procedure     :	wdog_refresh
Arguments 	  : Null
Return		  : Null
Description	  : Refresh WDT.
*******************************************************************************/
void wdog_refresh(void)
{
	/* This sequence must execute within 20 clock cycles, so disable
         * interrupts will keep the code atomic and ensure the timing.
         */
    DisableInterrupts;
	
	/* Write 0xA602 to the refresh register */
	WDOG_REFRESH = 0xA602;
	
	/* Followed by 0xB480 to complete the refresh */
	WDOG_REFRESH = 0xB480;
	
	/* Re-enable interrupts now that we are done */	
    EnableInterrupts;
}

