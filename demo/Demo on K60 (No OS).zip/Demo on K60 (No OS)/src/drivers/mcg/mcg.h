/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		mcg.h
** Descriptions:	pll_driver specific declarations
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef __MCG_H__
#define __MCG_H__
   

#ifdef __cplusplus
extern "C" 	{
#endif

  
typedef enum clk_option
{
  PLL100,
  PLL96,
  PLL50,
  PLL48,
}CLK_OPT;

typedef enum crystal_val
{
  XTAL2,
  XTAL4,
  XTAL8, 
  XTAL16,
  XTAL32,
  XTAL12,
  EXTAL50
}CRYSTAL_VAL;

  
/****************************variable declaration******************************/
extern  uint32  core_clk_mhz;
extern  uint32  core_clk_khz;
extern  uint32  bus_clk_khz;


/****************************function declaration******************************/
extern  void    mcg_pee_2_blpi(void);
extern  void    mcg_blpi_2_pee(void);
extern  void    mcg_pbe_2_pee(void);
extern  uint8   SystemClockInit(CLK_OPT want_clock, CRYSTAL_VAL crystal_val);
extern  __ramfunc void set_sys_dividers(uint32 outdiv1, uint32 outdiv2, uint32 outdiv3, uint32 outdiv4);


#ifdef __cplusplus 
} 
#endif 

#endif /* __MCG_H__ */
