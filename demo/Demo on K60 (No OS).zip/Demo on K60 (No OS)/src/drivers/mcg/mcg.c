/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		mcg.c
** Descriptions:	Driver for enabling the PLL in 1 of 4 options, the default 
**                  clockmode is FEI, But if you want to transfer to other mode, 
**                  the sequence must be followed.The following mode operetions 
**                  are: FEI, FEE, FBI, BLPI, FBE, BLPE, PBE, PEE.
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#include "system.h"
#include "mcg.h"


/*************************extern variable declaration**************************/


/*************************extern function declaration**************************/


/****************************variable declaration******************************/
/* Actual system clock frequency */
uint32 core_clk_mhz;       //core clock(MHz)
uint32 core_clk_khz;       //core clock(KHz)
uint32 bus_clk_khz;        //peripheral bus clock(KHz) //periph_clk_khz


/****************************function declaration******************************/


/*******************************************************************************
Procedure     :	SystemClockInit
Arguments 	  : [in]want_clock: wanted clock option
                [in]crystal_val: actual crystal option
Return		  : core clock frequency in MHz
Description	  : input the wanted clock and the selected crystal, then output the PLLOUT.
                1.First move to FBE mode(noted that if it is needed to transfer  
                  to PEE, the workflow(FEI-FBE-PBE-PEE) must be followed.)
                2.LP=0, IRCS=0, FLL(PLL)mode is not disable in bypass mode, and  
                  32k slow IRC is selected.(FLL is operational but is not used, 
                  so called bypass mode.)
                3.it assums that our extern clock is all larger than 1M, so we  
                  select the High frequency range, which is used in the followed 
                  MCG_C1 setting. 
*******************************************************************************/
uint8 SystemClockInit(CLK_OPT want_clock, CRYSTAL_VAL crystal_val)
{
    unsigned char pll_freq;

    if (want_clock > 3) {return 0;}  /* return 0 if one of the available options is not selected */
    if (crystal_val > 6) {return 1;} /* return 1 if one of the available crystal options is not available */
 
    // MCG is in default FEI mode out of reset.  
    if (crystal_val == EXTAL50)  //EXTEL50
        MCG_C2 = MCG_C2_RANGE(2); 
    else 
        MCG_C2 = MCG_C2_RANGE(2) | MCG_C2_HGO_MASK | MCG_C2_EREFS_MASK;
    
    // after initialization of oscillator release latched state of oscillator and GPIO
    SIM_SCGC4 |= SIM_SCGC4_LLWU_MASK;
    LLWU_CS |= LLWU_CS_ACKISO_MASK;    

    /*
     *  CLKS=2, FRDIV=Optional, IREFS=0, IRCLKEN=0, IREFSTEN=0 
     *  In FBE mode, select external clock as MCGOUTCLK, input clock of FLL is 
     *  fractional frequency of exrern clocl divided by 'FRDIV',
     *  must insure the fractional frequency is in the range of 31.25~39.0625. 
     *  Of course if you don't use output of FLL as MCGOUTCLK finally(e.g. FEE), 
     *  you need not consider this condition. This program use PLL instead of FLL, 
     *  so it's unnecessary to strictly obey that condition. 
     */
    if (crystal_val == XTAL12)       //XTAL12
    {
      /* the resulting frequeency is 23.4375KHz 
         Since that it's unable to set in range of 31.25~39.0625 when using a 
         12MHz extern clock, we can only make a compromise. */
        MCG_C1 = MCG_C1_CLKS(2) | MCG_C1_FRDIV(4);   
    }
    else if (crystal_val == EXTAL50) //EXTAL50
        MCG_C1 = MCG_C1_CLKS(2) | MCG_C1_FRDIV(5); /* the resulting frequeency is 48.828KHz( Best of a bad bunch) */
    else 
        MCG_C1 = MCG_C1_CLKS(2) | MCG_C1_FRDIV(crystal_val+1); /*others, can meet the requirements*/

    //if we aren't using an osc input it don't need to wait for the osc to init
    if (crystal_val != EXTAL50)
        while (!(MCG_S & MCG_S_OSCINIT_MASK)){}; /* wait for oscillator to initialize */

    while (MCG_S & MCG_S_IREFST_MASK){}; /* wait for Reference clock Status bit to clear */

    while (((MCG_S & MCG_S_CLKST_MASK) >> MCG_S_CLKST_SHIFT) != 0x2){}; /* Wait for clock status bits to show clock source is ext ref clk */

    //Now in FBE at last, we finish the first step, go on? yes, go on to PBE.
    
/*  PLLCLKEN=0, PLLSTEN=0, so MCGPLLCLK is diabled
 *  MCG_C5_PRDIV is used to divide the extern clock to the range of 2M~4M
 */
    switch (crystal_val)
    {
        case XTAL2: MCG_C5 = MCG_C5_PRDIV(0);     //2M/1 = 2M
            break;
        case XTAL4: MCG_C5 = MCG_C5_PRDIV(1);     //4M/2 = 2M
            break;
        case XTAL8: MCG_C5 = MCG_C5_PRDIV(3);     //8M/4 = 2M
            break;
        case XTAL16:MCG_C5 = MCG_C5_PRDIV(7);     //16M/8 = 2M
            break;
        case XTAL32:MCG_C5 = MCG_C5_PRDIV(15);    //32M/16 = 2M
            break;
        case XTAL12:MCG_C5 = MCG_C5_PRDIV(5);     //12M/6 = 2M
            break;
        case EXTAL50:MCG_C5 = MCG_C5_PRDIV(0x18); //50M/25 = 2M
            break;
        default:
            break;
    }

    /* Ensure MCG_C6 is at the reset default of 0. LOLIE disabled, PLL disabled, 
       clk monitor disabled, PLL VCO divider is clear.*/    
    MCG_C6 = 0x0;         
    
/* 
 *  select the multiply factor according to your want_clock and give a set of all clocks 
 *  distribution(core,bus,FlexBus,Flash clock) recommened in the datasheet.
 */
    switch (want_clock) 
    {
    case PLL100:
        // Set system options dividers
        /* MCG=PLL, core = MCG, bus = MCG/2, FlexBus = MCG/2, Flash clock= MCG/4 */
        set_sys_dividers(0,1,1,3);
        /* Set the VCO divider and enable the PLL for 100MHz, LOLIE=0, PLLS=1, CME=0, VDIV=26 */
        MCG_C6 = MCG_C6_PLLS_MASK | MCG_C6_VDIV(26);    /* VDIV = 26 (multiply factor=x50) */
        pll_freq = 100;
        break;
    case PLL96:
        // Set system options dividers
        /* MCG=PLL, core = MCG, bus = MCG/2, FlexBus = MCG/2, Flash clock= MCG/4 */
        set_sys_dividers(0,1,1,3);
        /* Set the VCO divider and enable the PLL for 96MHz, LOLIE=0, PLLS=1, CME=0, VDIV=24 */
        MCG_C6 = MCG_C6_PLLS_MASK | MCG_C6_VDIV(24);    /* VDIV = 24 (x48) */
        pll_freq = 96;
        break;
     case PLL50:
        // Set system options dividers
        /* MCG=PLL, core = MCG, bus = MCG, FlexBus = MCG, Flash clock= MCG/2 */
        set_sys_dividers(0,0,0,1);
        /* Set the VCO divider and enable the PLL for 50MHz, LOLIE=0, PLLS=1, CME=0, VDIV=1 */
        MCG_C6 = MCG_C6_PLLS_MASK | MCG_C6_VDIV(1);     /* VDIV = 1 (x25) */
        pll_freq = 50;
        break;
    case PLL48:
        // Set system options dividers
        /* MCG=PLL, core = MCG, bus = MCG, FlexBus = MCG, Flash clock= MCG/2 */
        set_sys_dividers(0,0,0,1);
        /* Set the VCO divider and enable the PLL for 48MHz, LOLIE=0, PLLS=1, CME=0, VDIV=0 */
        MCG_C6 = MCG_C6_PLLS_MASK;                      /* VDIV = 0 (x24) */
        pll_freq = 48;
        break;
    default:
        break; 
    }
    
    while (!(MCG_S & MCG_S_PLLST_MASK)){}; /* wait for PLL status bit to set */

    while (!(MCG_S & MCG_S_LOCK_MASK)){}; /* Wait for LOCK bit to set */

    // Now we are running PBE Mode,the go on to PEE Mode(the last step)

    // Transition into PEE by setting CLKS to 0
    /* CLKS=0, FRDIV=3, IREFS=0, IRCLKEN=0, IREFSTEN=0 */
    MCG_C1 &= ~MCG_C1_CLKS_MASK;

    /* Wait for clock status bits to update */
    while (((MCG_S & MCG_S_CLKST_MASK) >> MCG_S_CLKST_SHIFT) != 0x3){};

    // Now running PEE Mode, so we succed in making the system to run with wanted clock.

    #if 0
  	//130513henryang.add
    /* Use the value obtained from the pll_init function to define variables
     * for the core clock in kHz and also the peripheral clock. These
     * variables can be used by other functions that need awareness of the
     * system frequency.
     */
    core_clk_mhz = pll_freq;
    core_clk_khz = core_clk_mhz * 1000;
    bus_clk_khz = core_clk_khz / (((SIM_CLKDIV1 & SIM_CLKDIV1_OUTDIV2_MASK) >> 24)+ 1);        
    #endif
    
    return pll_freq;
}

/*******************************************************************************
Procedure     :	set_sys_dividers
Arguments 	  : [in]outdiv1: 
                [in]outdiv2: 
                [in]outdiv3: 
                [in]outdiv4: 
Return		  : Null
Description	  : This routine must be placed in RAM. It is a workaround for errata e2448.
                Flash prefetch must be disabled when the flash clock divider is changed.
                This cannot be performed while executing out of flash.
                There must be a short delay after the clock dividers are changed 
                before prefetch can be re-enabled.
*******************************************************************************/
__ramfunc void set_sys_dividers(uint32 outdiv1, uint32 outdiv2, uint32 outdiv3, uint32 outdiv4)
{

  uint32 temp_reg;
  uint8 i;
  
  temp_reg = FMC_PFAPR;  /* store present value of FMC_PFAPR */
  
  // set M0PFD through M7PFD to 1 to disable prefetch
  FMC_PFAPR |= FMC_PFAPR_M7PFD_MASK | FMC_PFAPR_M6PFD_MASK | FMC_PFAPR_M5PFD_MASK
             | FMC_PFAPR_M4PFD_MASK | FMC_PFAPR_M3PFD_MASK | FMC_PFAPR_M2PFD_MASK
             | FMC_PFAPR_M1PFD_MASK | FMC_PFAPR_M0PFD_MASK;
  
  // set clock dividers to desired value  
  SIM_CLKDIV1 = SIM_CLKDIV1_OUTDIV1(outdiv1) | SIM_CLKDIV1_OUTDIV2(outdiv2) 
              | SIM_CLKDIV1_OUTDIV3(outdiv3) | SIM_CLKDIV1_OUTDIV4(outdiv4);

  // wait for dividers to change
  for (i = 0; i < outdiv4; i++)
  {}
  
  FMC_PFAPR = temp_reg;           /* re-store original value of FMC_PFAPR */
  
  return;
}


// the following routine is given by official routines, we maybe don't need it

/*******************************************************************************
Procedure     :	mcg_pee_2_blpi
Arguments 	  : Null 
Return		  : Null
Description	  : MCG PEE to BLPI.
*******************************************************************************/
void mcg_pee_2_blpi(void)
{
    uint8 temp_reg;
    // Transition from PEE to BLPI: PEE -> PBE -> FBE -> FBI -> BLPI
  
    // Step 1: PEE -> PBE
    MCG_C1 |= MCG_C1_CLKS(2);                         /* System clock from external reference OSC, not PLL. */
    while (((MCG_S & MCG_S_CLKST_MASK) >> MCG_S_CLKST_SHIFT) != 0x2){};   /* Wait for clock status to update. */
    
    // Step 2: PBE -> FBE
    MCG_C6 &= ~MCG_C6_PLLS_MASK;                      /* Clear PLLS to select FLL, still running system from ext OSC. */
    while (MCG_S & MCG_S_PLLST_MASK){};               /* Wait for PLL status flag to reflect FLL selected. */
    
    // Step 3: FBE -> FBI
    MCG_C2 &= ~MCG_C2_LP_MASK;                        /* FLL remains active in bypassed modes. */
    MCG_C2 |= MCG_C2_IRCS_MASK;                       /* Select fast (1MHz) internal reference */
    temp_reg = MCG_C1;
    temp_reg &= ~(MCG_C1_CLKS_MASK | MCG_C1_IREFS_MASK);
    temp_reg |= (MCG_C1_CLKS(1) | MCG_C1_IREFS_MASK); /* Select internal reference (fast IREF clock @ 1MHz) as MCG clock source. */
    MCG_C1 = temp_reg;
  
    while (MCG_S & MCG_S_IREFST_MASK){};              /* Wait for Reference Status bit to update. */
    while (((MCG_S & MCG_S_CLKST_MASK) >> MCG_S_CLKST_SHIFT) != 0x1){};  /* Wait for clock status bits to update */
    
    // Step 4: FBI -> BLPI
    MCG_C1 |= MCG_C1_IREFSTEN_MASK;                   /* Keep internal reference clock running in STOP modes. */
    MCG_C2 |= MCG_C2_LP_MASK;                         /* FLL remains disabled in bypassed modes. */
    while (!(MCG_S & MCG_S_IREFST_MASK)){};           /* Wait for Reference Status bit to update. */
    while (((MCG_S & MCG_S_CLKST_MASK) >> MCG_S_CLKST_SHIFT) != 0x1){};  /* Wait for clock status bits to update. */
  
} 

/*******************************************************************************
Procedure     :	mcg_blpi_2_pee
Arguments 	  : Null 
Return		  : Null
Description	  : MCG BLPI to PEE.
*******************************************************************************/
void mcg_blpi_2_pee(void)
{
    uint8 temp_reg;
    // Transition from BLPI to PEE: BLPI -> FBI -> FEI -> FBE -> PBE -> PEE
  
    // Step 1: BLPI -> FBI 
    MCG_C2 &= ~MCG_C2_LP_MASK;                        /* FLL remains active in bypassed modes. */
    while (!(MCG_S & MCG_S_IREFST_MASK)){};           /* Wait for Reference Status bit to update. */
    while (((MCG_S & MCG_S_CLKST_MASK) >> MCG_S_CLKST_SHIFT) != 0x1){};  /* Wait for clock status bits to update */
    
    // Step 2: FBI -> FEI
    MCG_C2 &= ~MCG_C2_LP_MASK;                         /* FLL remains active in bypassed modes. */
    temp_reg = MCG_C2;                                 /* assign temporary variable of MCG_C2 contents. */
    temp_reg &= ~MCG_C2_RANGE_MASK;                    /* set RANGE field location to zero. */
    temp_reg |= (0x2 << 0x4);                          /* OR in new values */
    MCG_C2 = temp_reg;                                 /* store new value in MCG_C2. */
    MCG_C4 = 0x0E;                                     /* Low-range DCO output (~10MHz bus).  FCTRIM=%0111. */
    MCG_C1 = 0x04;                                     /* Select internal clock as MCG source, FRDIV=%000, internal reference selected. */
 
    while (!(MCG_S & MCG_S_IREFST_MASK)){};            /* Wait for Reference Status bit to update. */
    while (((MCG_S & MCG_S_CLKST_MASK) >> MCG_S_CLKST_SHIFT) != 0x0){}; /* Wait for clock status bits to update */
    
    // Handle FEI to PEE transitions using standard clock initialization routine.
    core_clk_mhz = SystemClockInit(MCG_CLK_MHZ, CRYSTAL_OPT); 

    /* Use the value obtained from the pll_init function to define variables
    * for the core clock in kHz and also the peripheral clock. These
    * variables can be used by other functions that need awareness of the
    * system frequency.
    */
    core_clk_khz = core_clk_mhz * 1000;
    bus_clk_khz = core_clk_khz / (((SIM_CLKDIV1 & SIM_CLKDIV1_OUTDIV2_MASK) >> 24)+ 1);        
} // end MCG BLPI to PEE

/*******************************************************************************
Procedure     :	mcg_pbe_2_pee
Arguments 	  : Null 
Return		  : Null
Description	  : MCG pbe to PEE.
*******************************************************************************/
void mcg_pbe_2_pee(void)
{  
  MCG_C1 &= ~MCG_C1_CLKS_MASK;      /* select PLL as MCG_OUT */
  //----Wait for clock status bits to update 
  while (((MCG_S & MCG_S_CLKST_MASK) >> MCG_S_CLKST_SHIFT) != 0x3){}; 

  switch (MCG_CLK_MHZ) {
    case PLL50:
      core_clk_khz = 50000;
      break;
    case PLL100:
      core_clk_khz = 100000;
      break;
    case PLL96:
      core_clk_khz = 96000;
      break;  
    case PLL48:
      core_clk_khz = 48000;
      break;  
  }
}