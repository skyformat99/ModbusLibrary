/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		rs485.c
** Descriptions:	RS-485 port support 
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-09-03
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#include "system.h"
#include "rs485.h"


/* set RS485 output device */
#define RS485_CHANNEL "ittyb:"

/* set RS485 Transmit Enable pin */
#define RS485_TE_PIN		(GPIO_PORT_C | GPIO_PIN2)
#define RS485_MUX_TE_PIN	(LWGPIO_MUX_C2_GPIO)


/*************************extern variable declaration**************************/
static 	MQX_FILE_PTR 	rs485_dev = NULL;
static 	LWGPIO_STRUCT	gioTE;
static 	uint32			rs485LastRcvTime = 0; //ms

/*************************extern function declaration**************************/


/****************************variable declaration******************************/


/****************************function declaration******************************/


/*******************************************************************************
Procedure :	Rs485Open
Parameter : [in]baud: wanted baud rate
			[in]parity: parity setting, ('N' 'E' or 'O')
Return	  : TRUE-Initialization success
			FALSE-Initialization failed (invalid input)
Descrip   :	Initialize RS485 port, set baudrate and parity.
Comment   :	
*******************************************************************************/
uint8 Rs485Open(uint32 baud, uint8 parity)
{
	uint8 paritymode = IO_SERIAL_PARITY_NONE;
	uint32 result;
	
	/* Open 485 channel */
	rs485_dev = fopen(RS485_CHANNEL, NULL/*(char const *)IO_SERIAL_NON_BLOCKING*/);
	if( rs485_dev == NULL )
	{
		/* device could not be opened */
		printf("485 device could not be opened.\n");
		_task_block();
	}	
	
	result = ioctl(rs485_dev, IO_IOCTL_SERIAL_SET_BAUD, &baud);
	if( result == IO_ERROR_INVALID_IOCTL_CMD )
	{
	   printf("Setting baudrate failed.\n");
	  _task_block();
	}
	
	switch(parity)
	{
		case  'E':
		case  'e':
			paritymode = IO_SERIAL_PARITY_EVEN;
			break;
		case  'O':
		case  'o':
			paritymode = IO_SERIAL_PARITY_ODD;
			break;
		default:
			break;	
	}
	result = ioctl(rs485_dev, IO_IOCTL_SERIAL_SET_PARITY, &paritymode);
	if( result == IO_ERROR_INVALID_IOCTL_CMD )
	{
	   printf("Setting parity failed.\n");
	  _task_block();
	}
	
	/* HW 485 flow control using pin PC2 */
	if (!lwgpio_init(&gioTE, RS485_TE_PIN, LWGPIO_DIR_OUTPUT, LWGPIO_VALUE_NOCHANGE))
	{
		printf("Initializing Transmit Enable GPIO as output failed.\n");
		_task_block();
	}
	lwgpio_set_functionality(&gioTE, RS485_MUX_TE_PIN);
	
	/* clear pin to 0 to enable receiving at initialization. */
	lwgpio_set_value(&gioTE, LWGPIO_VALUE_LOW); 
	
	return TRUE;
}

/*******************************************************************************
Procedure :	Rs485Write
Parameter : [in]pData: pointer to the data to be send out
			[in]size: length of data
Return	  : TRUE-sending successful, 
			FALSE-sending failed
Descrip   :	Write data into RS485 port to be sent out.
Comment   :	
*******************************************************************************/
BOOL8 Rs485Write(uint8 *pData, uint16 size)
{   
	uint32 result;
	boolean isDone = FALSE;
	
	/* set pin to 1 to enable transmission. */
	lwgpio_set_value(&gioTE, LWGPIO_VALUE_HIGH);
	   
	/* write data */
	write( rs485_dev, pData, size );
	   
	/* empty queue - not needed for polled mode */
	fflush( rs485_dev );
	   
	/* wait for TC was not good enough, some data was lost */
	while (!isDone) {
	   //_time_delay(1);
	   ioctl(rs485_dev, IO_IOCTL_SERIAL_TX_DRAINED, &isDone);   
	}
	
	/* wait for transfer complete flag */
	result = ioctl( rs485_dev, IO_IOCTL_SERIAL_WAIT_FOR_TC, NULL );
	if( result == IO_ERROR_INVALID_IOCTL_CMD ) 
	{
		printf("Wait for Transmit complete failed.\n");
		_task_block();
	}

	/* clear pin to 0 to enable receiving. */
	lwgpio_set_value(&gioTE, LWGPIO_VALUE_LOW); 
	
	return TRUE;
}

/*******************************************************************************
Procedure :	Rs485GetRcvCnt
Parameter : Null
Return	  :	count of received data 
Descrip   :	Get quantity of RX data.
*******************************************************************************/
uint16 Rs485GetRcvCnt()
{
	static uint16 rcvCnt = 0;
	uint32 tmpCnt;
	uint32 result;
		
	result = ioctl( rs485_dev, IO_IOCTL_GET_RX_SIZE, &tmpCnt );
	if( result == IO_ERROR_INVALID_IOCTL_CMD ) 
	{
		_task_block();
	}
	if (rcvCnt !=  tmpCnt)
	{
		if (tmpCnt)
		{
			rs485LastRcvTime = GetGTime();			
		}
		rcvCnt = tmpCnt;
	}
	return rcvCnt;
}

/*******************************************************************************
Procedure :	Rs485GetLastRcvTime
Parameter : Null
Return	  :	time of last data received (1ms)
Descrip   :	Get time of last data received of modbus.
*******************************************************************************/
uint32 Rs485GetLastRcvTime()
{
	return rs485LastRcvTime;
}


/*******************************************************************************
Procedure :	Rs485Read
Parameter : [out]pDes: destination to save received data
Return	  : length of received data
Descrip   :	Get received data out from port.
*******************************************************************************/
uint16 Rs485Read(uint8 *pDes)
{
	uint32	len;	
	
	/* read data */
	len = read( rs485_dev, pDes, Rs485GetRcvCnt() );
	return len;
}
