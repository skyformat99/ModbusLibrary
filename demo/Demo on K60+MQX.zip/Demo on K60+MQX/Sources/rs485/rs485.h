/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		rs485.h
** Descriptions:	RS-485 port support 
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-09-03
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef __RS485_H__
#define __RS485_H__

#ifdef __cplusplus
extern "C" 	{
#endif


  
/******************************macro definition********************************/
#define	UART0_USE_RT_SWITCH

  
/*******************************data definition********************************/


/****************************variable declaration******************************/


/*******************************macro operation********************************/


/****************************function declaration******************************/
extern	uint8 	Rs485Open(uint32 baud, uint8 parity);
extern	BOOL8 	Rs485Write(uint8 *pData, uint16 size);
extern	uint16 	Rs485GetRcvCnt(void);
extern	uint32 	Rs485GetLastRcvTime(void);
extern	uint16 	Rs485Read(uint8 *pDes);



#ifdef __cplusplus 
} 
#endif 

#endif 
