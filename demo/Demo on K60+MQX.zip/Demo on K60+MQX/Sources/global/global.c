/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		global.c
** Descriptions:	global functions or defines 
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-09-03
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#include "system.h"
#include "global.h"



/*************************extern variable declaration**************************/


/*************************extern function declaration**************************/


/****************************variable declaration******************************/


/****************************function declaration******************************/



/*******************************************************************************
Procedure :	GetGTime
Parameter : Null
Return	  :	current global time value (ms)
Descrip   :	Get current global time value. (ms)
Comment   :	precision: -1ms
*******************************************************************************/
uint32 GetGTime()
{
	TIME_STRUCT t;
	_time_get(&t);
	return (t.SECONDS * 1000 + t.MILLISECONDS);
}

/*******************************************************************************
Procedure :	GetInterval
Parameter : [in]prevTime: previous reference time (ms)
Return	  :	the interval from reference time to current time (ms) 
Descrip   :	get the interval from reference time to current time. (ms)
Comment   :	range: 0~4294967295ms (1193.046 hours, or 49.71 days)
			precision: +-1ms, 
*******************************************************************************/
uint32 GetInterval(uint32 prevTime)
{
	uint32 curTime;
	
	curTime = GetGTime();
	if (curTime < prevTime)
	{
		return (0xFFFFFFFF - prevTime + 1 + curTime);
	}
	return (curTime - prevTime);
}

/*******************************************************************************
Procedure :	GetDiffMs
Parameter : [in]pStartTime: start_time_ptr Pointer to the normalized start time in 
			second/millisecond time.
Return	  :	Difference in microseconds from start time to current time (ms) 
Descrip   :	get the interval from reference time to current time. (ms)
Comment   :	range: 0~4294967295ms (1193.046 hours, or 49.71 days)
			precision: +-1ms, 
*******************************************************************************/
uint32 GetDiffMs(TIME_STRUCT_PTR pStartTime)
{
	TIME_STRUCT 	endTime;
	TIME_STRUCT 	intervalTime;

	_time_get(&endTime);
    _time_diff(pStartTime, &endTime, &intervalTime);
    return (intervalTime.SECONDS * 1000 + intervalTime.MILLISECONDS);
}


