/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		global.h
** Descriptions:	global functions or defines 
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-09-03
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef __GLOBAL_H__
#define __GLOBAL_H__

#ifdef __cplusplus
extern "C" 	{
#endif


  
/******************************macro definition********************************/

  
/*******************************data definition********************************/


/****************************variable declaration******************************/


/*******************************macro operation********************************/


/****************************function declaration******************************/
extern	uint32 	GetGTime(void);
extern	uint32 	GetInterval(uint32 prevTime);
extern	uint32 	GetDiffMs(TIME_STRUCT_PTR pStartTime);



#ifdef __cplusplus 
} 
#endif 

#endif 
