/*******************************************************************************
** Copyright (c) 2012 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		common.h
** Descriptions:	definition of general-purpose operation or common symbol
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2012-12-12
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef COMMON_H
#define COMMON_H

#include "datatype.h"
#include "circlebuf.h"
#include "myassert.h"


#ifdef 	COMMON_C
	#define	EXTERN
#else
	#define EXTERN	extern
#endif


#ifdef __cplusplus
extern "C" 	{
#endif


/***********************definition of common used macro************************/
#ifdef	FALSE
#undef	FALSE
#endif
#define FALSE	(0)

#ifdef	TRUE
#undef	TRUE
#endif
#define	TRUE	(1)

#ifdef	NULL
#undef	NULL
#endif
#define NULL	(0)

#ifdef  ON
#undef  ON
#endif
#define ON      (1)

#ifdef  OFF
#undef  OFF
#endif
#define OFF     (0)

#ifdef  FAIL
#undef  FAIL
#endif
#define FAIL    (-1)

#ifdef  PASS
#undef  PASS
#endif
#define PASS    (0)
  
#ifdef  SCCS
#undef  SCCS
#endif
#define SCCS    (1)

/*
#ifndef TRUE
#define TRUE  	1
#endif

#ifndef FALSE
#define FALSE 	0
#endif

#ifndef NULL
#define NULL 	0
#endif

#ifndef ON
#define ON  	1
#endif

#ifndef OFF
#define OFF  	0
#endif

#ifndef FAIL
#define FAIL  	-1
#endif

#ifndef PASS
#define PASS  	0
#endif

#ifndef SCCS
#define SCCS  	1
#endif
*/
  
/* "bit" position mask definitions */
/*
#define BIT0    (0x01)
#define BIT1    (0x02)
#define BIT2    (0x04)
#define BIT3    (0x08)
#define BIT4    (0x10)
#define BIT5    (0x20)
#define BIT6    (0x40)
#define BIT7    (0x80)
#define BIT8    (0x0100u)
#define BIT9    (0x0200u)
#define BIT10   (0x0400u)
#define BIT11   (0x0800u)
#define BIT12   (0x1000u)
#define BIT13   (0x2000u)
#define BIT14   (0x4000u)
#define BIT15   (0x8000u)
#define BIT16   (0x00010000uL)
#define BIT17   (0x00020000uL)
#define BIT18   (0x00040000uL)
#define BIT19   (0x00080000uL)
#define BIT20   (0x00100000uL)
#define BIT21   (0x00200000uL)
#define BIT22   (0x00400000uL)
#define BIT23   (0x00800000uL)
#define BIT24   (0x01000000uL)
#define BIT25   (0x02000000uL)
#define BIT26   (0x04000000uL)
#define BIT27   (0x08000000uL)
#define BIT28   (0x10000000uL)
#define BIT29   (0x20000000uL)
#define BIT30   (0x40000000uL)
#define BIT31   (0x80000000uL)
*/
  
/* Logical Operators */
#define AND       &&
#define OR        ||
#define NOT       !
#define ISNOT     !=
#define IS        ==
#define MORE_THAN >
#define LESS_THAN <

/* Comparision operators */
#define EQ  ==
#define GE  >=
#define GT  >
#define LE  <=
#define LT  <
#define NE  !=

/* Bitwise operators */
#define BAND  &
#define BITOR |
#define BXOR  ^
#define BNOT  ~
#define LSHF  <<
#define RSHF  >>


#define Min(v0, v1) 	((v0>v1) ? v1 : v0)
#define Max(v0, v1) 	((v0>v1) ? v0 : v1)

/* get a byte from a appointed address */
#define MEM_B(x)	    (*((uint8*)(x)))		
/* get a word from a appointed address */
#define MEM_W(x)	    (*((uint16*)(x)))	

/* convert two bytes to a word according to LSB format */
#define FLIPW(ray)	    ((((uint16)(ray)[0]) * 256) + (ray)[1])
/* convert a word to two bytes according to LSB format */
#define FLOPW(ray, val)	(ray)[0] = ((val) / 256); (ray)[1] = ((val) & 0xFF)

/* get low byte from a word */
#define WORD_LOW(x)	    ((uint8)((uint16)(x) & 255))	
/* get high byte from a word */
#define WORD_HIGH(x)	((uint8)((uint16)(x) >> 8))	

/* convert a letter to capital format */
#define UPCASE(c)	    ( ((c) >= 'a' && (c) <= 'z') ? ((c) - 0x20) : (c) )

/* convert a ascii format digit to binary format. 
   only '0'-'9', 'A'-'F' are supported, 'a'-'f' are not applicable. */
#define ASC_TO_BIN(a)	    ( ((a) < 'A') ? ((a) - 0x30) : ((a) - 0x37) )

/* convert a binary format digit to ascii format 
   hexadecimal digit 0xA-0xF is converted to uppercase 'A'-'F', instead of lowercase 'a'-'f'. */
#define BIN_TO_ASC(b)	    ( ((b) < 0x0A) ? ((b) + 0x30) : ((b) + 0x37) )

/* check a char whether it's a number */
#define IS_NUM(c)	    ( ((c) >= '0' && (c) <= '9') ? (1) : (0) )

/* increasing with preventing overflow */
#define INC_SAT(val) 	(val = ((val) + 1 > (val)) ? (val) + 1 : (val))

/* Macro to TEST the specified bit_operand(mask form) is Set or Clear status */
#define TESTBIT(operand_value, bit_operand) 	(((operand_value) & (bit_operand)) != ((bit_operand) - (bit_operand)))
/* Macro to SET the specified bit_operand */
#define SETBIT(operand_value, bit_operand) 	    ((operand_value) |= (bit_operand))
/* Macro to CLEAR the specified bit_operand */
#define CLEARBIT(operand_value, bit_operand)	((operand_value) &= ((uint32)~(bit_operand)))//? or ~((uint32)(bit_operand))

/* bit operation use MARCOs */ //note: default data type for complier
#define	BitTest(p, nBitOfs)	    ((p) & (0x1 << (nBitOfs)))
#define	BitGet(p, nBitOfs)	    (((p) & (0x1 << (nBitOfs))) >> (nBitOfs))
#define	BitSet(p, nBitOfs) 	    ((p) |= (0x1 << (nBitOfs)))
#define	BitClr(p, nBitOfs)  	((p) &= ~(0x1 << (nBitOfs)))
/* 32 Bits data series bit operation use MARCOs */ //note: integral promotion
#define	BitTest32(p, nBitOfs)	((p) & ((uint32)0x1 << (nBitOfs)))
#define	BitGet32(p, nBitOfs)	(((p) & ((uint32)0x1 << (nBitOfs))) >> (nBitOfs))
#define	BitSet32(p, nBitOfs) 	((p) |= ((uint32)0x1 << (nBitOfs)))
#define	BitClr32(p, nBitOfs)  	((p) &= ~((uint32)0x1 << (nBitOfs)))


  
/*************************extern function declaration**************************/
extern 	uint16	CRC16(uint8 *puchMsg, uint8 usDataLen);
extern 	void	DelayShort(uint32 dly);
extern 	void	DelayLong(uint32 dly, uint32 cntOfdly);
extern 	void 	delayms(uint32 ms);
extern 	uint8* 	CopyDataWithDesPtrMove(uint8* ptr1, uint8* ptr2, uint32 len);
extern 	uint8 	Upset(uint8 dat);
extern 	uint8 	Upset6Bit(uint8 dat);
extern 	uint8 	Upset4Bit(uint8 dat);
extern 	uint8 	Upset2Bit(uint8 dat);
extern 	uint16 	FabsSub(uint16 data1, uint16 data2);
extern 	uint8 	AscToBin(uint8 ascData);
extern 	uint8 	BinToAsc(uint8 binData);
extern 	uint8 	AscDecStrToBin(uint8 *str, uint8 *pdata);
extern 	void 	BinToAscDecStr(uint8 data, uint8 *dstr);
extern 	uint8 	AscDecNumDecre(uint8 *str);
extern	uint32 	RoundDiv(uint32 x, uint32 y);
extern	uint32 	Sqrt(uint32 x);
extern	uint32 	CumuSquare(uint16 *pData, uint16 len);
extern	uint32 	RootMeanSquare(uint16 *pData, uint16 len);
extern	uint16 	MidlFilter(uint16 *pData, uint16 len);


#ifdef __cplusplus 
} 
#endif 

#undef EXTERN
#endif
