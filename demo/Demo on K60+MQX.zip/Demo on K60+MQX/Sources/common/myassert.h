/*******************************************************************************
** Copyright (c) 2013 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		myassert.h
** Descriptions:	define of ASSERT macro to calls assert_failed()
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2013-05-15
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef _MYASSERT_H_
#define _MYASSERT_H_


#ifdef __cplusplus
extern "C" 	{
#endif


extern  void    assert_failed(char *, int);


#ifdef DEBUG
#define ASSERT(expr) \
    if (!(expr)) \
        assert_failed(__FILE__, __LINE__)
#else
#define ASSERT(expr)
#endif

          
#ifdef __cplusplus 
} 
#endif 

#endif /* _ASSERT_H_ */

