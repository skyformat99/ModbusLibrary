/*******************************************************************************
** Copyright (c) 2012 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		common.c
** Descriptions:	definition of general-purpose operation or common symbol
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2012-12-12
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#define	COMMON_C

#include "common.h"


#define	CRC_CHAR	uint8


/*************************extern variable declaration**************************/


/*************************extern function declaration**************************/


/****************************variable declaration******************************/
/* Table of CRC values for high�Corder byte */ 
const CRC_CHAR  auchCRCHi[] ={
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	};

/* Table of CRC values for low�Corder byte */
const CRC_CHAR  auchCRCLo[] ={
    0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04,
	0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0XC9, 0x09, 0x08, 0xC8,
	0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC,
	0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3, 0x11, 0xD1, 0xD0, 0x10,
	0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4,
	0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38,
	0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C,
	0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,	0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0,
	0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4,
	0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68,
	0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C,
	0xB4, 0x74, 0x75, 0xB5, 0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0,
	0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54,
	0x9C, 0x5C, 0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98,
	0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
	0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80, 0x40,
	};

/****************************function declaration******************************/


/*******************************************************************************
Procedure     :	CRC16
Arguments     : uint8 *puchMsg: message to calculate CRC upon
                uint8 usDataLen: quantity of bytes in message
Return	      : uint16: the CRC check value
Description   : calculate CRC check value
*******************************************************************************/
uint16 CRC16(uint8 *puchMsg, uint8 usDataLen)
{
	uint8	uchCRCHi = 0xFF;
	uint8	uchCRCLo = 0xFF;
	uint32	uIndex = 0;
		
	while (usDataLen--)
	{
		uIndex = uchCRCHi ^ *puchMsg++; 
		
		#ifdef	PUT_CRC_TBL_IN_PROG
			uchCRCHi = uchCRCLo ^ pgm_read_byte(&auchCRCHi[uIndex]);
	    	uchCRCLo = pgm_read_byte(&auchCRCLo[uIndex]);
		#else
			uchCRCHi = uchCRCLo ^ auchCRCHi[uIndex];
	    	uchCRCLo = auchCRCLo[uIndex];
		#endif
	}
	return (uchCRCHi << 8 | uchCRCLo);
}

/*******************************************************************************
Procedure     :	DelayShort
Arguments 	  : uint32 dly: delay value
Return		  : NULL
Description	  : This procedure produces a short software delay
*******************************************************************************/
void DelayShort(uint32 dly)
{  
	uint32 	i;
 	for (i=0; i < dly; i++)
        asm("nop");
}

/*******************************************************************************
Procedure     :	DelayShort
Arguments 	  : uint32 dly: major delay value
				uint32 cntOfdly: minor delay value
Return		  : NULL
Description	  : This procedure produces a long software delay
*******************************************************************************/
void DelayLong(uint32 dly, uint32 cntOfdly)
{  
    uint32  i;

    for (; dly > 0; dly--) 
        for (i=0; i < cntOfdly; i++)
            asm("nop");
}

/*******************************************************************************
Procedure     :	delayms
Arguments 	  : [in]ms: millisecond count for delay  
Return		  : NULL
Description	  : This procedure produces a delay of appointed count of millisecond. 
Comment		  :	Used for K60 @100MHz. 
				This method only provide a approximate delay, for accurate delay,
				please use timer.
*******************************************************************************/
void delayms(uint32 ms)
{  
	/*volatile*/ uint32  i;

    for (; ms>0; ms--) 
        for (i=0; i<16666; i++) //K60 @100MHz
            asm("nop");
}

/*******************************************************************************
Procedure     :	CopyDataWithDesPtrMove
Arguments 	  : ptr1: target pointer
				ptr2: source pointer
				len: length of data that will be copied
Return		  : ptr1 that after be moved 
Description	  : Copy the data indicatd by ptr2 to the area indirect by ptr1,
              	the length of data that will be copied is 'len'. At the same
              	time, ptr1 move forward for a 'len' distance.
*******************************************************************************/
uint8* CopyDataWithDesPtrMove(uint8* ptr1, uint8* ptr2, uint32 len)
{
	memcpy(ptr1, ptr2, len);
	ptr1 += len;
	return ptr1;
}

/*******************************************************************************
Procedure     :	Upset
Arguments 	  : dat:
Return		  : upset value of 'dat'
Description	  : Get upset of byte.
*******************************************************************************/
uint8 Upset(uint8 dat)//dat=12345678
{
	dat = (dat >> 4) | (dat << 4); //dat=56781234
	dat = ((dat & 0xcc) >> 2) | ((dat & 0x33) << 2); //dat=78563412
	dat = ((dat & 0xaa) >> 1) | ((dat & 0x55) << 1); //dat=87654321
	return dat;
}

/*******************************************************************************
Procedure     :	Upset6Bit
Arguments 	  : dat: only low 6 bit is avaliable
Return		  : upset value of 'dat'
Description	  : Get upset of a 6 bit data.
*******************************************************************************/
uint8 Upset6Bit(uint8 dat)//dat=123456
{
	dat = ((dat & 0x30) >> 4) | ((dat & 0x03) << 4) | (dat & 0x0C); //dat=563412
	dat = ((dat & 0x2A) >> 1) | ((dat & 0x15) << 1); //dat=654321
	return dat;
}
/* 	//method 2
	dat = ((dat & 0x38) >> 3) | ((dat & 0x07) << 3); //dat=456123
	dat = ((dat & 0x24) >> 2) | ((dat & 0x09) << 2) | (dat & 0x12); //dat=654321
	return dat;
*/

/*******************************************************************************
Procedure     :	Upset4Bit
Arguments 	  : dat: only low 4 bit is avaliable
Return		  : upset value of 'dat'
Description	  : Get upset of a 4 bit data.
*******************************************************************************/
uint8 Upset4Bit(uint8 dat)//dat=1234
{
	dat = ((dat & 0xC) >> 2) | ((dat & 0x3) << 2); //dat=3412
	dat = ((dat & 0xA) >> 1) | ((dat & 0x5) << 1); //dat=4321
	return dat;
}

/*******************************************************************************
Procedure     :	Upset2Bit
Arguments 	  : dat: only low 2 bit is avaliable
Return		  : upset value of 'dat'
Description	  : Get upset of a 2 bit data.
*******************************************************************************/
uint8 Upset2Bit(uint8 dat)//dat=12
{
	return (((dat & 0x2) >> 1) | ((dat & 0x1) << 1)); //dat=21
}


/*******************************************************************************
Procedure     :	FabsSub
Arguments 	  : [in]data1:
				[in]data2:
Return		  : absolute value of 'data1' subtract from 'data2'
Description	  : Get absolute value of 'data1' subtract from 'data2'.
*******************************************************************************/
uint16 FabsSub(uint16 data1, uint16 data2)
{
	if (data1 >= data2)
		return (data1 - data2);
	return (data2 - data1);
}

/*******************************************************************************
Procedure     :	AscToBin
Arguments 	  : [in]ascData: ascii data to be converted. '0'-'9','A'-'F','a'-'f'
Return		  : binary format data 
				if input data invalid, return -1(0xFF).
Description	  : Convert a ascii data to binary data.
*******************************************************************************/
uint8 AscToBin(uint8 ascData)
{
	if ((ascData < '0') || (ascData > 'f'))
		return FAIL;

	if (ascData >= 'a')
	{
		ascData -= 0x20; //convert 'a' to 'A'
	}
	
	if(ascData >= 'A')
		return (ascData - 0x37);
	else
		return (ascData - 0x30);	
}

/*******************************************************************************
Procedure     :	BinToAsc
Arguments 	  : [in]binData: binary data to be converted. 0x0-0xF
Return		  : ascii format data 
				if input data invalid, return -1(0xFF).
Description	  : Convert a binary data to ascii data.
Comment		  :	Hexadecimal digit 0xA-0xF is converted to uppercase 'A'-'F', 
				instead of lowercase 'a'-'f'.
*******************************************************************************/
uint8 BinToAsc(uint8 binData)
{
	if (binData > 0x0F)
		return FAIL;

	if(binData >= 0x0A)
		return (binData + 0x37);
	else
		return (binData + 0x30);	
}

/*******************************************************************************
Procedure     :	AscDecStrToBin
Arguments 	  : [in]str: source ascii format string of decimal numbers
				[out]pdata: pointer to char saving output binary format number value
Return		  : TRUE- successful
				FALSE- failed
Description	  : Convert a ascii format digit number string to binary format.
Comment		  :	process restriction: number less than "256"
				only support string of ascii format of decimal digit, '0'-'9'.
				e.g. String "123" is converted to byte 0x7B. 
*******************************************************************************/
uint8 AscDecStrToBin(uint8 *str, uint8 *pdata)
{
	uint8 n = 0;
	
	if ((n = strlen(str)) > 3)
		return FALSE;

	*pdata = 0;
	while (n--)
	{
		if (!IS_NUM(*str))
			return FALSE;
		*pdata = (*pdata) * 10 + ASC_TO_BIN(*str);
		str++;
	}
	return TRUE;
}

/*******************************************************************************
Procedure     :	BinToAscDecStr
Arguments 	  : [in]data: input binary number value to be converted to ascii format   
				[out]dstr: destination string to save convert result 
Return		  : Null
Description	  : Convert a binary format number to ascii format string in decimal digit.
Comment		  :	process restriction: number less than 256
				e.g. Byte 0x7B is converted to string "123". 
*******************************************************************************/
void BinToAscDecStr(uint8 data, uint8 *dstr)
{
	uint8 digit = 0;

	digit = data / 100;
	if (digit)
	{
		*dstr++ = BIN_TO_ASC(digit);
		data = data % 100;
	}
	digit = data / 10;
	if (digit)
	{
		*dstr++ = BIN_TO_ASC(digit);
		data = data % 10;
	}
	*dstr++ = BIN_TO_ASC(data);	
	*dstr = 0; //add a end char for safety
}

/*******************************************************************************
Procedure     :	AscDecNumDecre
Arguments 	  : [in, out]str: source ascii format string of decimal numbers, 
				also desitination to save result string after been decreased by 1.
Return		  : TRUE- successful
				FALSE- failed
Description	  : Decrease a ascii format decimal number string by '1'.
				e.g. reduce "25" to "24"
Comment 	  : process restriction: number less than 256
				if string equal to "0", outcome not change.
*******************************************************************************/
uint8 AscDecNumDecre(uint8 *str)
{
	uint8 data;

	if (!AscDecStrToBin(str, &data))
		return FALSE;
	
	if (data)
		data--;

	BinToAscDecStr(data, str);
	return TRUE;
}

/*******************************************************************************
Procedure     :	RoundDiv
Arguments 	  : x: dividend
				y: divisor
Return		  : uint32: round result of x/y
Description	  : get round integral result of x/y
*******************************************************************************/
uint32 	RoundDiv(uint32 x, uint32 y)
{
	uint32	mod;        
	uint32	rem;
	
	mod = x / y;
	rem = x % y;
	if ((rem<<1) >= y)
	{
		return (mod + 1);
	}
	return mod;
}


/*******************************************************************************
Procedure     :	Sqrt
Arguments 	  : uint32 x
Return		  : uint32: square root of x
Description	  : get square root of input data
*******************************************************************************/
uint32 	Sqrt(uint32 x)
{
	uint32	tentative;
	uint16	probe = 0;
	uint16	root = 0;
	uint8	i = 16;

	tentative = x;
	while (--i)
	{
		if (tentative & 0xC0000000)
		{
			break;
		}
		tentative <<= 2;
	}

	probe = 0x1 << i;
	while (probe)
	{
		root += probe;
		tentative = (uint32)root * root;
		if (x == tentative)
		{
			return root;
		}
		else if (x < tentative)
		{
			root -= probe;
		}
		probe >>= 1;
	}

	if (x > (uint32)root * root + root)
	{
		return ((uint32)root + 1);
	}
	return root;
}


/*******************************************************************************
Procedure     :	CumuSquare
Arguments 	  : uint16 *pData: head pointer of data 
 				uint16 len: amount of data
Return		  : uint32: cumulation of squares of input data
Description	  : get cumulation of squares of multi-data 
*******************************************************************************/
uint32 	CumuSquare(uint16 *pData, uint16 len)
{
	uint32	ret = 0;

	while (len--)
	{
		ret += (uint32)(*pData) * (*pData++);
	}
	
	return ret;
}

/*******************************************************************************
Procedure     :	RootMeanSquare
Arguments 	  : uint16 *pData: head pointer of data 
 				uint16 len: amount of data
Return		  : uint32: root mean square of input data
Description	  : get root mean square of multi-data 
*******************************************************************************/
uint32 	RootMeanSquare(uint16 *pData, uint16 len)
{
	if (!len)
		return 0;
	return Sqrt(CumuSquare(pData, len) / len);
}


/*******************************************************************************
Function Name :	MidlFilter
Arguments 	  : uint16 *pData: pointer of sample values
				uint16 len: quantity of sample value
Return		  : uint16: filter value
Description	  : median-average filter
*******************************************************************************/
uint16 MidlFilter(uint16 *pData, uint16 len)
{
	uint32 	sum = 0;
	uint16 	counter = 0, min = 0, max = 0;

	if ((pData == NULL) || (!len))
		return FALSE;

	min = max = *pData;

	for(counter=0; counter<len; counter++)
	{
		sum += *(pData + counter);
		if (*(pData + counter) < min)
		{
			min = *(pData+counter);
		}
		if (*(pData+counter) > max)
		{
			max = *(pData+counter);
		}
	}
	if (len < 3)
	{
		return (sum / len);
	}

	return ((sum-max-min) / (len-2));
}


/*******************************************************************************
**                            End Of File
*******************************************************************************/




