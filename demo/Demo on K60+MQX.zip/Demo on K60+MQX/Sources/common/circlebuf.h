/*******************************************************************************
** Copyright (c) 2011 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		circlebuf.h
** Descriptions:	process of circle buffer 
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2012-12-12
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#ifndef CIRCLEBUF_H
#define CIRCLEBUF_H


#ifdef 	COMMON_C
	#define	EXTERN
#else
	#define EXTERN	extern
#endif


#ifdef __cplusplus
extern "C" 	{
#endif

typedef struct 
{
	uint8*	pBuf;
	uint16	size;
	uint16 	dataCnt;
	uint8	*pRead;
	uint8	*pWrite;
}CIRCLEBUF, *CIRCLEBUF_PTR;


#define	CBUF_SIZE(pbuf)				((pbuf)->size)
#define	CBUF_DATA_SIZE(pbuf)		((pbuf)->dataCnt)
#define	CBUF_SPARE_SIZE(pbuf)		(((pbuf)->size) - ((pbuf)->dataCnt))


//function declaration
extern	uint8 	CBufInit(CIRCLEBUF* pCircleBuf, uint8* pBuf, uint16 sizeOfBuf);
extern	void 	CBufRst(CIRCLEBUF* pCircleBuf);
extern	uint8 	CBufIsEmpty(CIRCLEBUF* pCircleBuf);
extern	uint8 	CBufIsFull(CIRCLEBUF* pCircleBuf);
extern	uint8 	CBufWillBeOverflow(CIRCLEBUF* pCircleBuf, uint16 amount);
extern	uint8 	CBufWillBeDataLack(CIRCLEBUF* pCircleBuf, uint16 amount);
extern	uint8 	CBufPutChar(CIRCLEBUF* pCircleBuf, uint8	chInput);
extern	uint16 	CBufPutData(CIRCLEBUF* pCircleBuf, uint8* pData, uint16 len);
extern	uint8 	CBufGetChar(CIRCLEBUF* pCircleBuf, uint8* pchOutput);
extern	uint16 	CBufGetData(CIRCLEBUF* pCircleBuf, uint8* pDes, uint16 len);
extern	uint16 	CBufCopyBlock(CIRCLEBUF* pCircleBuf, uint8* pDes, uint8* pHead, uint8* pTail);
extern	uint8* 	CBufReadSkip(CIRCLEBUF* pCircleBuf, uint16 len);
extern	void 	CBufFlushEmpty(CIRCLEBUF* pCircleBuf);
extern	uint8* 	CBufPtrAdd(CIRCLEBUF* pCircleBuf, uint8* pCurrent);
extern	uint16 	CBufDistance(CIRCLEBUF* pCircleBuf, uint8* ptr1, uint8* ptr2);

#ifdef __cplusplus 
} 
#endif 

#undef EXTERN
#endif
