/*******************************************************************************
** Copyright (c) 2012 Trojan Technologies Inc. 
** All rights reserved.
**
** File name:		circlebuf.c
** Descriptions:	process of circle buffer 
**------------------------------------------------------------------------------
** Version:		    1.0
** Created by:		Hengguang 
** Created date:	2012-12-12
** Descriptions:	The original version
**------------------------------------------------------------------------------
** Version:				
** Modified by:			
** Modified date:		
** Descriptions:		
*******************************************************************************/
#define	CIRCLEBUF_C

#include "common.h"
#include "circlebuf.h"


#define	MIN_CBUF_SIZE	2

#define _CBUF_INLINE

/*************************extern variable declaration**************************/


/*************************extern function declaration**************************/


/****************************variable declaration******************************/


/****************************function declaration******************************/



/*******************************************************************************
Procedure     :	CBufInit
Arguments 	  : pCircleBuf: pointer of circle buffer to be initialized
 	  		    pBuf: head pointer of objective buffer 
				sizeOfBuf: size of objective buffer 
Return		  : TRUE-success
				FALSE-failed
Description	  : initialization of circle buffer
*******************************************************************************/
uint8 CBufInit(CIRCLEBUF* pCircleBuf, uint8* pBuf, uint16 sizeOfBuf)
{
	if ((NULL == pCircleBuf) || (NULL == pBuf)) 
		return FALSE;
	
	if (sizeOfBuf < MIN_CBUF_SIZE)
		return FALSE;
	
	pCircleBuf->pBuf = pBuf;
	pCircleBuf->size = sizeOfBuf;
	pCircleBuf->pRead = pBuf;
	pCircleBuf->pWrite = pBuf;
	pCircleBuf->dataCnt = 0;
	return TRUE;
}

/*******************************************************************************
Procedure     :	CBufRst
Arguments 	  : pCircleBuf: pointer of target circle buffer
Return		  : Null
Description	  : reset circle buffer
*******************************************************************************/
void CBufRst(CIRCLEBUF* pCircleBuf)
{
	pCircleBuf->pRead = pCircleBuf->pBuf;
	pCircleBuf->pWrite = pCircleBuf->pBuf;
	pCircleBuf->dataCnt = 0;
}

/*******************************************************************************
Procedure     :	CBufIsEmpty
Arguments 	  : pCircleBuf: pointer of target circle buffer
Return		  : TRUE-the circle buffer is empty
				FALSE-the circle buffer isn't empty
Description	  : check if circle buffer is empty
*******************************************************************************/
#ifdef _CBUF_INLINE
inline 
#endif
uint8 CBufIsEmpty(CIRCLEBUF* pCircleBuf)
{
	return (pCircleBuf->dataCnt == 0);
}

/*******************************************************************************
Procedure     :	CBufIsFull
Arguments 	  : pCircleBuf: pointer of target circle buffer
Return		  : TRUE-the circle buffer is full
				FALSE-the circle buffer isn't full
Description	  : check if circle buffer is full
*******************************************************************************/
#ifdef _CBUF_INLINE
inline 
#endif
uint8 CBufIsFull(CIRCLEBUF* pCircleBuf)
{
	return (pCircleBuf->dataCnt == pCircleBuf->size);
}

/*******************************************************************************
Procedure     :	CBufWillBeOverflow
Arguments 	  : pCircleBuf: pointer of target circle buffer
				amount: quantity of bytes will be written in
Return		  : TRUE-circle buffer will be overflow
				FALSE-circle buffer won't be overflow
Description	  : check if circle buffer will be overflow when attempt to 
				write data in.
*******************************************************************************/
#ifdef _CBUF_INLINE
inline 
#endif
uint8 CBufWillBeOverflow(CIRCLEBUF* pCircleBuf, uint16 amount)
{
	return ((pCircleBuf->size - pCircleBuf->dataCnt) < amount);
}

/*******************************************************************************
Procedure     :	CBufWillBeDataLack
Arguments 	  : pCircleBuf: pointer of target circle buffer
				amount: quantity of bytes will be got out
Return		  : TRUE-data in circle buffer will be lack
				FALSE-data in circle buffer is enough
Description	  : check if circle buffer will be lack for get data out.
*******************************************************************************/
#ifdef _CBUF_INLINE
inline 
#endif
uint8 CBufWillBeDataLack(CIRCLEBUF* pCircleBuf, uint16 amount)
{
	return (pCircleBuf->dataCnt < amount);
}

/*******************************************************************************
Procedure     :	CBufPutChar
Arguments 	  : pCircleBuf: pointer of target circle buffer
 	  		    chInput: input char
Return		  : TRUE-success
				FALSE-failed, buffer is full
Description	  : put a char into circle buffer
*******************************************************************************/
uint8 CBufPutChar(CIRCLEBUF* pCircleBuf, uint8 chInput)
{
	if (CBufIsFull(pCircleBuf))
		return FALSE;

	*(pCircleBuf->pWrite++) = chInput;
	if (pCircleBuf->pWrite == pCircleBuf->pBuf + pCircleBuf->size)
	{
		pCircleBuf->pWrite = pCircleBuf->pBuf;
	}
	pCircleBuf->dataCnt++;	
	return TRUE;
}

/*******************************************************************************
Procedure     :	CBufPutData
Arguments 	  : pCircleBuf: pointer of target circle buffer
 	  		    pData: head pointer of data
				len: amount of data to be put in
Return		  : count of data actually be put in. 
				0-failed, buffer is full
Description	  : put a series of data into circle buffer
*******************************************************************************/
uint16 CBufPutData(CIRCLEBUF* pCircleBuf, uint8* pData, uint16 len)
{
	uint16	bottomSize;

	if (len == 0)
		return 0;
	
	if (CBufWillBeOverflow(pCircleBuf, len))
		return 0;

	bottomSize = pCircleBuf->pBuf + pCircleBuf->size - pCircleBuf->pWrite;
	if (len <= bottomSize)
	{
		memcpy(pCircleBuf->pWrite, pData, len);
		if (len == bottomSize)
		{
			pCircleBuf->pWrite = pCircleBuf->pBuf;
		}
		else
		{
			pCircleBuf->pWrite += len;
		}
	}
	else
	{
		memcpy(pCircleBuf->pWrite, pData, bottomSize);
		memcpy(pCircleBuf->pBuf, pData + bottomSize, len - bottomSize);
		pCircleBuf->pWrite = pCircleBuf->pBuf + len - bottomSize;
	}
	pCircleBuf->dataCnt += len;
	return len;		
}

/*******************************************************************************
Procedure     :	CBufGetChar
Arguments 	  : pCircleBuf: pointer of target circle buffer
 	  		    pchOutput: address to save output char
Return		  : TRUE-success
				FALSE-failed, buffer is empty
Description	  : get a char out from circle buffer
*******************************************************************************/
uint8 CBufGetChar(CIRCLEBUF* pCircleBuf, uint8* pchOutput)
{
	if (CBufIsEmpty(pCircleBuf))
		return FALSE;

	*pchOutput = *(pCircleBuf->pRead++);
	if (pCircleBuf->pRead == pCircleBuf->pBuf + pCircleBuf->size)
	{
		pCircleBuf->pRead = pCircleBuf->pBuf;
	}
	pCircleBuf->dataCnt--;	
	return TRUE;
}

/*******************************************************************************
Procedure     :	CBufGetData
Arguments 	  : pCircleBuf: pointer of target circle buffer
 	  		    pDes: pointer of destination to store output data 
				len: amount of data to be get out. 
					 0- means get all data out, that is read buffer to empty.
Return		  : count of data actually be get out. 
				0-failed, buffer is empty
Description	  : get a series of data out from circle buffer
*******************************************************************************/
uint16 CBufGetData(CIRCLEBUF* pCircleBuf, uint8* pDes, uint16 len)
{
	uint16	bottomSize;

	if (CBufIsEmpty(pCircleBuf))
		return 0;

	if ((len == 0) || (pCircleBuf->dataCnt < len))
	{
		len = pCircleBuf->dataCnt;
	}
	
	bottomSize = pCircleBuf->pBuf + pCircleBuf->size - pCircleBuf->pRead;
	if (len <= bottomSize)
	{
		memcpy(pDes, pCircleBuf->pRead, len);
		if (len == bottomSize)
		{
			pCircleBuf->pRead = pCircleBuf->pBuf;
		}
		else
		{
			pCircleBuf->pRead += len;
		}
	}
	else
	{
		memcpy(pDes, pCircleBuf->pRead, bottomSize);
		memcpy(pDes + bottomSize, pCircleBuf->pBuf, len - bottomSize);
		pCircleBuf->pRead = pCircleBuf->pBuf + len - bottomSize;
	}
	pCircleBuf->dataCnt -= len;
	return len;		
}

/*******************************************************************************
Procedure     :	CBufCopyBlock
Arguments 	  : pCircleBuf: pointer of target circle buffer
 	  		    pDes: pointer of destination to store output data 
				pHead: head pointer of data block
				pTail: tail pointer of data block
Return		  : count of data actually be copied out. 
				0-failed.
Description	  : copy a block of data out from circle buffer to a destination.
Comment		  :	data block is appointed by a given head and tail pointer, 
				regardless of whether data have been read. 
				This operation just copy a block, will not affect 'pRead' and 'cnt'.
*******************************************************************************/
uint16 CBufCopyBlock(CIRCLEBUF* pCircleBuf, uint8* pDes, uint8* pHead, uint8* pTail)
{
	uint16	n = 0;
	
	if ((pHead >= pCircleBuf->pBuf + pCircleBuf->size)
		|| (pTail >= pCircleBuf->pBuf + pCircleBuf->size))
	{
		return 0;
	}

	do 
	{
		*pDes++ = *pHead++;
		n++;
		if (pHead >= (pCircleBuf->pBuf + pCircleBuf->size)) //reach the tail of the array
			pHead = pCircleBuf->pBuf;
	}while(pHead != pTail);

	return n;
}

/*******************************************************************************
Procedure     :	CBufReadSkip
Arguments 	  : pCircleBuf: pointer of target circle buffer
 	  		    len: length of skip
Return		  : 'pRead' in circle buffer after skip
				If data in cirlce buffer is not enough, return FALSE.
Description	  : 'pRead' skip a distance of 'len' without copy data out.
*******************************************************************************/
uint8* CBufReadSkip(CIRCLEBUF* pCircleBuf, uint16 len)
{
	uint16	bottomSize;

	if (len > pCircleBuf->dataCnt)
		return FALSE;

	bottomSize = pCircleBuf->pBuf + pCircleBuf->size - pCircleBuf->pRead;
	if (len < bottomSize)
	{
		pCircleBuf->pRead += len;
	}
	else
	{
		pCircleBuf->pRead = pCircleBuf->pBuf + len - bottomSize;
	}
	pCircleBuf->dataCnt -= len;
	return (pCircleBuf->pRead);
}

/*******************************************************************************
Procedure     :	CBufFlushEmpty
Arguments 	  : pCircleBuf: pointer of target circle buffer
Return		  : Null.
Description	  : Flush circle buffer to empty.
*******************************************************************************/
void CBufFlushEmpty(CIRCLEBUF* pCircleBuf)
{
	pCircleBuf->pRead = pCircleBuf->pWrite;
	pCircleBuf->dataCnt = 0;
}

/*******************************************************************************
Procedure     :	CBufPtrAdd
Arguments 	  : pCircleBuf: pointer of target circle buffer
 	  		    pCurrent: current pointer that will be moved forward
Return		  : 'pCurrent' that after been moved forward by one 
Description	  : Get the position of the current pointer that added by one 
              	in the circle buffer. Be applied in array of UCHAR type.
*******************************************************************************/
uint8* CBufPtrAdd(CIRCLEBUF* pCircleBuf, uint8* pCurrent)
{
	pCurrent++;
	if (pCurrent >= (pCircleBuf->pBuf + pCircleBuf->size)) //reach the tail of the array
		pCurrent = pCircleBuf->pBuf;
	return pCurrent;
}

/*******************************************************************************
Procedure     :	CBufDistance
Arguments 	  : pCircleBuf: pointer of target circle buffer
 	  		    ptr1: head pointer
 	  		    ptr2: tail pointer
Return		  : distance between head pointer and tail pointer
Description	  : get the distance between appointed head pointer and tail 
              	pointer in the circle buffer.
              	Be applied in array of UCHAR type.
*******************************************************************************/
uint16 CBufDistance(CIRCLEBUF* pCircleBuf, uint8* ptr1, uint8* ptr2)
{
	if (ptr1 > ptr2)
		return pCircleBuf->size - (ptr1 - ptr2);
	else
		return (ptr2 - ptr1);
}



